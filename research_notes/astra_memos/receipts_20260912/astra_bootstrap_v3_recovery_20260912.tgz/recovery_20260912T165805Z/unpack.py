import base64
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).parent
node, label = sys.argv[1:]
package = json.loads((root/node/"queries"/(label+".stdout")).read_text())
inventory = dict(package)
inventory["files"] = []
for entry in package["files"]:
    relative = Path(entry["path"])
    assert not relative.is_absolute() and ".." not in relative.parts
    payload = base64.b64decode(entry["content_base64"])
    assert len(payload) == entry["bytes"] and hashlib.sha256(payload).hexdigest() == entry["sha256"]
    target = root/node/"files"/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as handle:
        handle.write(payload)
    inventory["files"].append({key: value for key,value in entry.items() if key != "content_base64"})
with (root/node/(label+".manifest.json")).open("x") as handle:
    json.dump(inventory, handle, indent=2)
print(json.dumps(dict(node=node, label=label, files=len(inventory["files"]), bytes=sum(entry["bytes"] for entry in inventory["files"]), missing=inventory.get("missing",[]))))
