import base64
import datetime
import hashlib
import json
from pathlib import Path

home = Path.home()
paths = ["v6_out/bootstrap_v3/" + name for name in
         ("corpus.json", "corpus_meta.json", "corpus_rows.jsonl", "TRAINED",
          "adapter/DONE", "adapter/adapter_config.json", "adapter/train_meta.json",
          "DEV_UNVERIFIED_PROVENANCE", "QUARANTINE_TASK_EXPOSED")]
paths += ["v6_out/bootstrap_v3.out", "train_bootstraps.sh", "dream-state/organism_v6/bootstrap_corpus.py"]
result = dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), files=[], missing=[])
total = 0
for relative in paths:
    path = home / relative
    if not path.is_file():
        result["missing"].append(relative)
        continue
    before = path.stat()
    if before.st_size > 3 * 1024 * 1024 or total + before.st_size > 5 * 1024 * 1024:
        result.setdefault("skipped_size", []).append(relative)
        continue
    payload = path.read_bytes()
    after = path.stat()
    total += len(payload)
    result["files"].append(dict(path=relative, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
        mtime_ns=before.st_mtime_ns, stable_stat=(before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
        content_base64=base64.b64encode(payload).decode()))
print(json.dumps(result))
