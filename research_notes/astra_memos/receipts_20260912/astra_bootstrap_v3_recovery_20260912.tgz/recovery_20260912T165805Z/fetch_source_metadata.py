import base64
import datetime
import hashlib
import json
from pathlib import Path

home=Path.home()
result=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), files=[], missing=[], skipped_size=[])
total=0
paths=[]
for directory in sorted((home/"v6_out").glob("lineage3_*")):
    if not directory.is_dir():
        continue
    paths += [directory/"parent_ledger.jsonl", directory/"parent_playbook.md"]
    for round_directory in sorted(directory.glob("round_*")):
        for name in ("parent_mode.json", "admission_receipts.json", "lineage_manifest.json", "manifest.json", "snapshot.json"):
            paths.append(round_directory/name)
for path in paths:
    relative=str(path.relative_to(home))
    if not path.is_file():
        result["missing"].append(relative)
        continue
    before=path.stat()
    if before.st_size>512*1024 or total+before.st_size>4*1024*1024:
        result["skipped_size"].append(dict(path=relative,bytes=before.st_size))
        continue
    payload=path.read_bytes()
    after=path.stat()
    total+=len(payload)
    result["files"].append(dict(path=relative,bytes=len(payload),sha256=hashlib.sha256(payload).hexdigest(),mtime_ns=before.st_mtime_ns,
        stable_stat=(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),content_base64=base64.b64encode(payload).decode()))
print(json.dumps(result))
