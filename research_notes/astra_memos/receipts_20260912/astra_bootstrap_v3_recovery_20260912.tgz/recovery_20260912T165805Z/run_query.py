import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).parent
node, label, script_name = sys.argv[1:]
wrappers = {"node1": "gpu/a40_ssh.sh", "node2": "gpu/ovx_ssh.sh"}
directory = root / node / "queries"
directory.mkdir(parents=True, exist_ok=True)
script = (root / script_name).read_text()
command = "python3 - <<'ASTRA_READ_ONLY_PY'\n" + script + "\nASTRA_READ_ONLY_PY"
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    result = subprocess.run(["bash", wrappers[node], command], capture_output=True, timeout=55)
    stdout, stderr, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as error:
    stdout, stderr, code = error.stdout or b"", error.stderr or b"", 124
for suffix, payload in (("stdout", stdout), ("stderr", stderr)):
    with (directory / (label + "." + suffix)).open("xb") as handle:
        handle.write(payload)
receipt = dict(node=node, label=label, started_utc=started,
               ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               wrapper=wrappers[node], exit_code=code, script=script_name,
               script_sha256=hashlib.sha256(script.encode()).hexdigest(),
               stdout_bytes=len(stdout), stderr_bytes=len(stderr),
               stdout_sha256=hashlib.sha256(stdout).hexdigest())
with (directory / (label + ".exit.json")).open("x") as handle:
    json.dump(receipt, handle, indent=2)
print(json.dumps(receipt))
