import datetime
import json
from pathlib import Path

home = Path.home()
output = dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), directories=[], producer_candidates=[])
for directory in sorted((home / "v6_out").glob("bootstrap*")):
    entry = dict(path=str(directory.relative_to(home)), is_dir=directory.is_dir(), files=[])
    if directory.is_dir():
        for path in sorted(directory.rglob("*")):
            relative = path.relative_to(directory)
            if len(relative.parts) > 3 or not path.is_file():
                continue
            entry["files"].append(dict(path=str(relative), bytes=path.stat().st_size))
            if len(entry["files"]) >= 100:
                entry["truncated"] = True
                break
    output["directories"].append(entry)
for parent in (home, home / "v6_out", home / "dream-state/gpu/node_scripts"):
    for pattern in ("*bootstrap*", "*rule*corpus*", "*corpus*rule*"):
        for path in sorted(parent.glob(pattern)):
            if path.is_file() and path.stat().st_size < 1024 * 1024:
                output["producer_candidates"].append(dict(path=str(path.relative_to(home)), bytes=path.stat().st_size))
output["lineage_roots"] = [str(path.relative_to(home)) for path in sorted((home / "v6_out").glob("lineage3_*")) if path.is_dir()]
print(json.dumps(output))
