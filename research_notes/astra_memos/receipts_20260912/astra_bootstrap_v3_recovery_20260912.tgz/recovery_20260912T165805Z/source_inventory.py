import collections
import datetime
import hashlib
import json
from pathlib import Path

home = Path.home()
result = dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), staging=[], producers=[], upstream=[])
for directory in sorted((home/"v6_out").glob("src_classroom*")):
    entry=dict(path=str(directory.relative_to(home)), files=[])
    for path in sorted(directory.glob("*")):
        if not path.is_file():
            continue
        info=dict(path=str(path.relative_to(home)), bytes=path.stat().st_size)
        if path.name == "ledger.jsonl" and path.stat().st_size < 80*1024*1024:
            payload=path.read_bytes()
            rows=[json.loads(line) for line in payload.splitlines() if line.strip()]
            info.update(sha256=hashlib.sha256(payload).hexdigest(), rows=len(rows),
                        keys=sorted(set(key for row in rows for key in row)),
                        kinds=dict(collections.Counter(row.get("kind") for row in rows)),
                        first_row_metadata={key:value for key,value in rows[0].items() if key not in ("prompt","note","outcome","action","text")})
        entry["files"].append(info)
    result["staging"].append(entry)
for parent in (home, home/"dream-state/gpu/node_scripts", home/"dream-state/organism_v6"):
    for pattern in ("*.sh", "*.py"):
        for path in sorted(parent.glob(pattern)):
            if not path.is_file() or path.stat().st_size > 300000:
                continue
            text=path.read_text(errors="replace")
            hits=[number for number,line in enumerate(text.splitlines(),1) if "src_classrooms" in line or "bootstrap_v3" in line]
            if hits:
                result["producers"].append(dict(path=str(path.relative_to(home)), bytes=path.stat().st_size, matching_lines=hits))
for directory in sorted((home/"v6_out").glob("lineage3_*")):
    if not directory.is_dir():
        continue
    files=[]
    for path in sorted(directory.glob("round_*/ledger_c*.jsonl")):
        files.append(dict(path=str(path.relative_to(home)), bytes=path.stat().st_size))
    result["upstream"].append(dict(path=str(directory.relative_to(home)), ledger_files=files))
print(json.dumps(result))
