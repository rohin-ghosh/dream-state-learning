import collections
import csv
import datetime
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).parent
source_root=root/"node2/files"
corpus_root=root/"node1/files/v6_out/bootstrap_v3"
rows=[json.loads(line) for line in (corpus_root/"corpus_rows.jsonl").read_text().splitlines() if line.strip()]
corpus=json.loads((corpus_root/"corpus.json").read_text())
meta=json.loads((corpus_root/"corpus_meta.json").read_text())
source=json.loads((root/"node2/queries/03_match.stdout").read_text())
matches={(entry["eid"],entry["q_sha256"]):entry for entry in source["matches"]}
source_files={entry["path"]:entry for entry in source["upstream_files"]}
ledger_bindings={}
manifest_audit=[]
for manifest in sorted(source_root.glob("v6_out/lineage3_*/round_*/manifest.json")):
    data=json.loads(manifest.read_text())
    for classroom,expected in enumerate(data["ledger_shas"]):
        relative=str((manifest.parent/("ledger_c%02d.jsonl" % classroom)).relative_to(source_root))
        actual=source_files.get(relative,{}).get("sha256")
        ledger_bindings[relative]=actual==expected
        manifest_audit.append(dict(path=relative,manifest=str(manifest.relative_to(source_root)),expected_sha256=expected,actual_sha256=actual,match=actual==expected))
screen=re.compile(r"CompilerGym|compiler_gym|benchmark://|cbench|mibench|\bLLVM\b|-mem2reg\b|-sroa\b|-simplifycfg\b|-gvn\b",re.I)
eid_pattern=re.compile(r"rule\d+/r\d+-c\d+-l\d+-[ab]")
parent_cache={}
for ledger in sorted(source_root.glob("v6_out/lineage3_*/parent_ledger.jsonl")):
    parent_cache[ledger.parent.name]=[(number,json.loads(line)) for number,line in enumerate(ledger.read_text().splitlines(),1) if line.strip()]
admission_cache={}
mode_cache={}
summary=collections.Counter()
mode_counts=collections.Counter()
records=[]
for index,row in enumerate(rows,1):
    prompt_hash=hashlib.sha256(row["q"].encode()).hexdigest()
    matched=matches[(row["eid"],prompt_hash)]
    candidates=[]
    for entry in matched["upstream"]:
        path=Path(entry["path"])
        round_path=source_root/path.parent
        key=str(path.parent)
        if key not in admission_cache:
            admission_cache[key]=json.loads((round_path/"admission_receipts.json").read_text())
            mode_cache[key]=json.loads((round_path/"parent_mode.json").read_text())
        mode=mode_cache[key]
        admissions=[dict(index=position,admitted=receipt["admitted"],evidence_ids=receipt["evidence_ids"],classroom=receipt["classroom"],lesson=receipt["lesson"])
                    for position,receipt in enumerate(admission_cache[key]) if row["eid"] in receipt.get("evidence_ids",[])]
        lineage=path.parts[1]
        pair_ids={evidence for receipt in admissions for evidence in receipt["evidence_ids"]}
        teacher_turns=[dict(line=number,kind=turn.get("kind"),source=turn.get("source"),evidence_ids=turn.get("evidence_ids"),ts=turn.get("ts"))
                       for number,turn in parent_cache.get(lineage,[]) if turn.get("kind")=="intervention" and pair_ids.intersection(turn.get("evidence_ids",[]))]
        candidates.append(dict(entry,ledger_sha256=source_files[entry["path"]]["sha256"],manifest_ledger_hash_matches=ledger_bindings.get(entry["path"]),
                               parent_mode=mode.get("parent"),parent_model_label=mode.get("model"),admissions=admissions,parent_intervention_receipts=teacher_turns))
    binding="UNIQUE_PRIMARY_PROMPT_MATCH" if len(candidates)==1 else "AMBIGUOUS_PRIMARY_PROMPT_MATCH" if candidates else "PRIMARY_PROMPT_NOT_FOUND"
    summary[binding]+=1
    if len(candidates)==1:
        mode_counts[candidates[0]["parent_mode"]]+=1
    hints=sorted(set(eid_pattern.findall(row["a"]))) if row["path"]=="contrast" else []
    reasons=["AUTHOR_REQUEST_REVISION_AND_RENDERING_SUPPORT_UNBOUND","SOURCE_EXPOSURE_HISTORY_NOT_AUTHENTICATED"]
    if len(candidates)!=1:
        reasons.append("SOURCE_INSTANCE_NOT_RECORDED_MULTIPLE_EXACT_PROMPTS")
    if row["path"]=="contrast":
        reasons.append("SECOND_CONTRAST_DEPENDENCY_NOT_RECORDED")
    record=dict(row_index_1based=index,row_sha256=hashlib.sha256(json.dumps(row,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest(),
                path=row["path"],src=row["src"],eid=row["eid"],q_sha256=prompt_hash,a_sha256=hashlib.sha256(row["a"].encode()).hexdigest(),
                primary_status=binding,staging_matches=matched["staging"],source_candidate_count=len(candidates),source_candidates=candidates,
                contrast_dependency_status="UNRESOLVED_NOT_RECORDED" if row["path"]=="contrast" else "NOT_APPLICABLE",
                contrast_text_eid_hints_only=hints,deployment_literal_hits={field:screen.findall(row[field]) for field in ("q","a")},
                rendering_provenance_status="UNRESOLVED",unresolved_reasons=reasons)
    records.append(record)
with (root/"row_provenance_audit.jsonl").open("x") as handle:
    for record in records:
        handle.write(json.dumps(record,sort_keys=True)+"\n")
columns=("row_index_1based","path","eid","primary_status","source_candidate_count","contrast_dependency_status","rendering_provenance_status","unresolved_reasons")
with (root/"row_provenance_audit.csv").open("x",newline="") as handle:
    writer=csv.DictWriter(handle,fieldnames=columns)
    writer.writeheader()
    for record in records:
        compact={key:record[key] for key in columns}
        compact["unresolved_reasons"]=";".join(record["unresolved_reasons"])
        writer.writerow(compact)
with (root/"source_manifest_binding_audit.json").open("x") as handle:
    json.dump(manifest_audit,handle,indent=2)
result=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=len(rows),ordered_qa_equal=corpus["corpus"]==[dict(q=row["q"],a=row["a"]) for row in rows],
            counts=dict(collections.Counter(row["path"] for row in rows)),counts_equal_meta=dict(collections.Counter(row["path"] for row in rows))==meta["paths"],
            primary_bindings=dict(summary),unique_primary_parent_modes=dict(mode_counts),manifest_ledger_matches=sum(entry["match"] for entry in manifest_audit),
            manifest_ledger_total=len(manifest_audit),source_staging_sha256=source["staging"]["sha256"],source_concat_equal=source["sorted_upstream_concat_equals_staging"],
            contrast_rows=sum(row["path"]=="contrast" for row in rows),contrast_rows_with_text_eid_hints=sum(bool(record["contrast_text_eid_hints_only"]) for record in records),
            deployment_literal_screen_hit_rows=sum(any(record["deployment_literal_hits"].values()) for record in records),
            unresolved_rendering_rows=sum(record["rendering_provenance_status"]=="UNRESOLVED" for record in records),
            stable_source_stats=all(entry["stable_stat"] for entry in source["upstream_files"]))
with (root/"audit_summary.json").open("x") as handle:
    json.dump(result,handle,indent=2)
print(json.dumps(result,indent=2))
