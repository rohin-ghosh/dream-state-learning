import hashlib
import json
from pathlib import Path

root=Path(__file__).parent
rows=[json.loads(line) for line in (root/"node1/files/v6_out/bootstrap_v3/corpus_rows.jsonl").read_text().splitlines() if line.strip()]
targets=sorted({(row["eid"],hashlib.sha256(row["q"].encode()).hexdigest()) for row in rows})
payload=[dict(eid=eid,q_sha256=prompt_hash) for eid,prompt_hash in targets]
script=(root/"source_match.py").read_text().replace("TARGETS_PLACEHOLDER",repr(payload))
with (root/"source_match_bound.py").open("x") as handle:
    handle.write(script)
