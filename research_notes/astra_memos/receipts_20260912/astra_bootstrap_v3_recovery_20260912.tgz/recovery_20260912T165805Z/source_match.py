import collections
import datetime
import hashlib
import json
from pathlib import Path
import sys

home = Path.home()
targets = TARGETS_PLACEHOLDER
target_keys = {(item["eid"], item["q_sha256"]) for item in targets}
result = dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), staging={}, upstream_files=[], matches=[], producer_candidates=[])
staging = home/"v6_out/src_classrooms/ledger.jsonl"
hash_stage = hashlib.sha256()
line_count = 0
kinds = collections.Counter()
keys = set()
stage_matches = collections.defaultdict(list)
before = staging.stat()
with staging.open("rb") as handle:
    for number, raw in enumerate(handle, 1):
        hash_stage.update(raw)
        if not raw.strip():
            continue
        row = json.loads(raw)
        line_count += 1
        kinds[row.get("kind")] += 1
        keys.update(row)
        prompt = row.get("prompt")
        if isinstance(prompt, str):
            key = (row.get("episode_id"), hashlib.sha256(prompt.encode()).hexdigest())
            if key in target_keys:
                stage_matches[key].append(dict(line=number, tick=row.get("tick"), kind=row.get("kind"), row_sha256=hashlib.sha256(raw).hexdigest()))
after = staging.stat()
result["staging"] = dict(path="v6_out/src_classrooms/ledger.jsonl", bytes=before.st_size, sha256=hash_stage.hexdigest(), rows=line_count,
                         kinds=dict(kinds), keys=sorted(keys), stable_stat=(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns))
concat = hashlib.sha256()
upstream_matches = collections.defaultdict(list)
offset_lines = 0
for directory in sorted((home/"v6_out").glob("lineage3_*")):
    if not directory.is_dir():
        continue
    for path in sorted(directory.glob("round_*/ledger_c*.jsonl")):
        file_hash = hashlib.sha256()
        file_lines = 0
        before = path.stat()
        with path.open("rb") as handle:
            for number, raw in enumerate(handle, 1):
                file_lines = number
                file_hash.update(raw)
                concat.update(raw)
                if not raw.strip():
                    continue
                row = json.loads(raw)
                prompt = row.get("prompt")
                if isinstance(prompt,str):
                    key=(row.get("episode_id"),hashlib.sha256(prompt.encode()).hexdigest())
                    if key in target_keys:
                        upstream_matches[key].append(dict(path=str(path.relative_to(home)), line=number, tick=row.get("tick"), kind=row.get("kind"), row_sha256=hashlib.sha256(raw).hexdigest()))
        after=path.stat()
        result["upstream_files"].append(dict(path=str(path.relative_to(home)), bytes=before.st_size, sha256=file_hash.hexdigest(), lines=file_lines,
            concat_start_line=offset_lines+1, stable_stat=(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)))
        offset_lines += file_lines
result["sorted_upstream_concat_sha256"]=concat.hexdigest()
result["sorted_upstream_concat_equals_staging"]=concat.hexdigest()==hash_stage.hexdigest()
for eid, prompt_hash in sorted(target_keys):
    result["matches"].append(dict(eid=eid,q_sha256=prompt_hash,staging=stage_matches[(eid,prompt_hash)],upstream=upstream_matches[(eid,prompt_hash)]))
print(json.dumps(result))
