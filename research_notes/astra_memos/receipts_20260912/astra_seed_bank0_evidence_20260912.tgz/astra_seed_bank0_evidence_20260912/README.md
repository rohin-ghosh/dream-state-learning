# Astra bank0 evidence capture — 2026-09-12 UTC

Remote source capture: 07:17:04–07:17:07 UTC, node2, read-only SSH. No prior capture was found in the requested location or bounded /tmp search. No remote writes, installs, model fetches, GPU launches, signals, or queue mutations were performed.

## Contents and integrity

- `runs/`: exact four bank0 eval JSONs; original seed-run receipts; every receipt-listed immutable source input; bank0 train metadata, DONE and throughput; separate 100-step profile metadata/MEASURED and logs. Profiles are not scientific fits and their default seed0 must not relabel the actual fits.
- `queue/`: original selected job records and timestamped log snapshots.
- `experiment_code/f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d/`: original frozen experiment code relevant to these runs.
- `CAPTURE_MANIFEST.json`: source paths, per-file SHA-256, byte counts and source modification times for 98 remote files (121,276,287 bytes). Every receipt-listed input was checked against its original receipt before transport; every transported file was checked after extraction. No model/adapter weights or reuse indexes were copied.
- `node2_bank0_source_capture.tar.gz`: original transport archive; SHA-256 `e5725880b35b80f0f54d93faa921d1e811506d399caac8d2b3b328beb2480db1`. This source archive does not include the later local analysis outputs; copy the whole directory for the complete bundle.
- `analysis_code/`: frozen copies of the actual analysis CLI, tests and required pure-Python source-validation/scientific-definition modules.
- `analysis.json`, `analysis.stderr`, `ANALYSIS_RECEIPT.json`: actual CLI output, empty stderr, exact argv/command, runtime, hashes and eligibility interpretation.
- `FINAL_PROGRESS.json`: the single end-of-task progress observation at 07:18:19 UTC, separate from the bank0 evidence capture.
- `SHA256SUMS`: checksums of every other bundle file, including the source archive and all analysis/progress artifacts.

## Exact command executed

```bash
bash /tmp/astra_seed_bank0_evidence_20260912/run_analysis.sh > /tmp/astra_seed_bank0_evidence_20260912/analysis.json 2> /tmp/astra_seed_bank0_evidence_20260912/analysis.stderr
```

Exit status 0. The shell wrapper invokes `python3 -B analysis_code/research_notes/analysis/astra_seed_campaign.py` with four explicit eval/train-meta/receipt triples and `--bootstrap-seed 0`; full absolute argv is in `ANALYSIS_RECEIPT.json`. The script reads captured bytes only and prints to stdout. Preserve existing outputs: rerun to stdout or a new output path, never overwrite this captured result. Run paths in the original receipts/eval JSONs are intentionally unchanged.

Output SHA-256 (`analysis.json`): `e7bd30eef0e37d9d164e43d2badfb8e9ceebc25a55d89384659ba42a4ac5ed65`.

## Eligibility and limits

All four bank0 entries have completed scientific-fit evidence, exact compatible source hashes, receipts and evaluable binding controls. They are eligible for descriptive, paired-source diagnostic analysis. All four fail the EXISTING G9 frame-binding gate. No new thresholds were fitted.

Not eligible for clean-lineage use or binding-success promotion. The `SYNTHETIC_DIAGNOSTIC_NOT_CLEAN_LINEAGE` label remains. No pooling across banks, assumption of independent optimizer seeds, H1/H2 claim, or completed-three-bank-stage claim follows from this bundle. Analysis-code eligibility is not GPU-launch authorization.

Final progress observation: A1 seed2/seed3 and A2 attempt2 seed0/seed1 remained queue-running, each with only bank0 fit and eval completed and no full-stage markers; A2 attempt2 seed2 remained pending with no fit/eval outputs. Main owns subsequent scheduling, logging and copying into the repo.
