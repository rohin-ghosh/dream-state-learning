#!/bin/bash
set -euo pipefail
bundle="$(dirname -- "$(realpath -- "$0")")"
arguments=()
for specification in \
  astra_A1_memory_dose_S1_F_r16k16_ts2_20260912:F_r16k16 \
  astra_A1_memory_dose_S1_F_r16k16_ts3_20260912:F_r16k16 \
  astra_A2_memory_dose_D32_CF_r16_b_ts0_20260912_attempt2:CF_r16_b \
  astra_A2_memory_dose_D32_CF_r16_b_ts1_20260912_attempt2:CF_r16_b
do
  IFS=: read -r name cell <<< "$specification"
  run="$bundle/runs/$name"
  arguments+=(--entry
    "$run/eval/bank0__${cell}__across__sleep4__r8__lam1.json"
    "$run/adapters/bank0/$cell/across/sleep4/r8/train_meta.json"
    "$run/seed_run_receipt.json")
done
exec python3 -B "$bundle/analysis_code/research_notes/analysis/astra_seed_campaign.py" \
  "${arguments[@]}" --bootstrap-seed 0
