import datetime
import hashlib
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import tarfile
import tempfile

repo = Path('/data/home/rohing/dream-state')
prior = Path('/tmp/astra_A2_seed2_terminal_20260912')
old_archive = repo / 'research_notes/astra_memos/receipts_20260912/astra_A2_seed2_snapshot_20260912T083402Z_raw.tgz'
root = Path(tempfile.mkdtemp(prefix='astra_A2_seed2_0905_recovery_', dir='/tmp'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(name, data):
    with (root / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')

prior_before = {path.relative_to(prior).as_posix(): digest(path) for path in sorted(prior.rglob('*')) if path.is_file()}
assert digest(old_archive) == '80a30ec80cfb53e856be00e7ae82f4a4a5aa6bdc3c56156ca264e32dd97536d8'
write_json('PRIOR_CUSTODY_BEFORE.json', {'archive_path': str(old_archive), 'archive_sha256': digest(old_archive), 'capsule_files': prior_before})
remote_script = Path('/tmp/astra_A2_seed2_0905_capture_remote.py')
shutil.copyfile(remote_script, root / remote_script.name)
shutil.copyfile(__file__, root / Path(__file__).name)
command = ['bash', 'gpu/ovx_ssh.sh', 'python3 -B -c ' + shlex.quote(remote_script.read_text())]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / 'transport.tar').open('xb') as stdout, (root / 'transport.stderr').open('xb') as stderr:
    result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr, timeout=180)
write_json('CAPTURE_COMMAND.json', {'argv': command, 'cwd': str(repo), 'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'returncode': result.returncode})
assert result.returncode == 0, str(root)
with tarfile.open(root / 'transport.tar') as archive:
    members = archive.getmembers()
    assert all(member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts for member in members)
    for member in members:
        target = root / member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(archive.extractfile(member).read())
manifest = json.loads((root / 'CAPTURE_MANIFEST.json').read_text())
for entry in manifest['files']:
    if not entry.get('missing') and not entry.get('hash_only'):
        assert digest(root / entry['capsule_path']) == entry['sha256']
shutil.copytree(prior / 'analysis_code', root / 'analysis_code')
reuse = [{'source': str(path), 'capsule_path': 'analysis_code/' + path.relative_to(prior / 'analysis_code').as_posix(), 'sha256': digest(path)}
         for path in sorted((prior / 'analysis_code').rglob('*')) if path.is_file()]
write_json('ANALYZER_REUSE.json', reuse)
shutil.copyfile(prior / 'analysis.json', root / 'PRIOR_BANK0_ANALYSIS.json')
shutil.copyfile(prior / 'README.md', root / 'PRIOR_README.md')
status = json.loads((root / 'STATUS_SNAPSHOT.json').read_text())
terminal = (not status['queue_pid_present'] and status['queue_rc'] is not None)
if terminal:
    analyzer = root / 'analysis_code/research_notes/analysis/astra_seed_campaign.py'
    assert digest(analyzer) == 'e1327b3d2fdc060e33aad3d088beada167226437a9b1e6f28b819c6b5959eea9'
    command = ['python3', '-B', str(analyzer)]
    for bank in status['banks']:
        if bank['fit_done'] and bank['eval_exists']:
            bank_index = bank['bank']
            command.extend(['--entry', str(root / 'run/eval' / Path(bank['eval_path']).name),
                str(root / f'run/adapters/bank{bank_index}/CF_r16_b/across/sleep4/r8/train_meta.json'),
                str(root / 'run/seed_run_receipt.json')])
    with (root / 'analysis.json').open('xb') as stdout, (root / 'analysis.stderr').open('xb') as stderr:
        result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, timeout=120)
    write_json('ANALYSIS_RECEIPT.json', {'argv': command, 'cwd': str(root), 'returncode': result.returncode,
        'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'stdout_sha256': digest(root / 'analysis.json'), 'stderr_sha256': digest(root / 'analysis.stderr')})
    assert result.returncode == 0, str(root)
prior_after = {path.relative_to(prior).as_posix(): digest(path) for path in sorted(prior.rglob('*')) if path.is_file()}
assert prior_before == prior_after
assert digest(old_archive) == '80a30ec80cfb53e856be00e7ae82f4a4a5aa6bdc3c56156ca264e32dd97536d8'
write_json('VALIDATION.json', {'remote_payload_hashes_verified': True,
    'unstable_remote_files': [entry for entry in manifest['files'] if entry.get('stable_during_read') is False],
    'prior_capsule_all_files_unchanged': True, 'prior_capsule_file_count': len(prior_after),
    'prior_archive_unchanged': True, 'prior_archive_sha256': digest(old_archive),
    'terminal_by_pid_absence_and_rc': terminal})
print(str(root))
print(json.dumps(status, indent=2))
