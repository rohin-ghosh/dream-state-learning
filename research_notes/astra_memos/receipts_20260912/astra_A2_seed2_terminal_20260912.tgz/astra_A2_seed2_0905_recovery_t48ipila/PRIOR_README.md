# A2 optimizer seed2 — bounded node2 snapshot, not terminal

**Still RUNNING at 2026-09-12 08:34:02.237069 UTC.** Queue0052 PID3560937 exists (PPID1823897, status Ss, process start 07:41:11; queue start 07:41:12 UTC), assigned GPU1. Run: `/localhome/local-rohing/v6_out/astra_A2_memory_dose_D32_CF_r16_b_ts2_20260912_attempt2`. No stage-completion marker. Directory name `terminal` is the requested task identifier, not a terminal-state assertion. No repeat status polling or waiting for completion.

Compared with the prior 08:04:18 snapshot (no completed fits/evals), **bank0 and bank1 now have fit DONE**, and **only bank0 has completed evaluation** in the single status snapshot. Bank0 TRAIN_DONE at08:05:22, EVAL_DONE at08:08:43; bank1 TRAIN_DONE at08:32:58. Fixed-scope evidence copying at08:35:05 did not expand to later evaluations. Bank1 evaluation and bank2 fit/evaluation remain unconfirmed/outstanding as of the status snapshot. No RC/final stage completion is claimed. The bounded captured queue log contains no error line; this is not a guarantee about all logs or future execution.

## New bank0 G9 result

Existing analyzer `research_notes/analysis/astra_seed_campaign.py`, copied byte-for-byte from the previous frozen analysis capsule, ran with bootstrap seed0 and unchanged definitions. Exit0, empty stderr. One new compatible evaluation with1313 cues, optimizer seed2, source bank seed0, cell CF_r16_b;16 dose16 paired owners, all16 OFF/ON controls valid for frame/similar/bicycle. No unavailable controls or source mismatch.

| Mean I_d_frame | Within-fit/bank95% percentile interval | Frame spill | G9 |
|---|---|---|---|
| 1.184902794133669 | [0.736801601373312, 1.8112251421790742] | 0.3231037216369375 | FAIL |

Unchanged G9: lower interval bound strictly >0 **and** frame_spill <=0.03. This bank has positive lower bound but excessive spill. Bootstrap uses2000 paired-owner resamples within this fit/bank; it does not estimate optimizer-seed uncertainty. `frame_similar` is a look-alike control, not an exposed-partner swapped-ID test. No controls were imputed; no pooling, causal comparison, threshold fitting or new metric implementation.

## Artifact counts versus seed counts

- New capture: **2 completed-fit receipts,1 completed fit/eval artifact,1 evaluated optimizer seed configuration**, not two independent seeds. Bank1 has training metadata/DONE but no evaluated G9 in this snapshot; it is not counted as a G9 failure or pass.
- Previous reviewed ledger:12 evaluated artifacts across A1 seeds2/3 and A2 seeds0/1, each over3 banks. Add this single bank0 artifact: **13 evaluated artifacts,13 G9 failures,0 passes** as a bookkeeping total, not a pooled success-rate inference. Prior jobs/banks were not re-inspected or reanalyzed.
- Family/optimizer configurations represented: A1 two (2,3), A2 three (0,1,2), total five family/seed configurations—not13 seeds and not five independent numerical seed values. A2 has7 evaluated bank artifacts (3+3+1); A1 has6. A2 seed2 remains incomplete across the planned3 banks.
- The analyzer's isolated new-entry output lists reference seeds0/1 as unavailable **within this one-entry analysis**, not globally missing. Prior source-identity JSON confirms exact bank0 input hashes match the previous A2 seeds0/1; those prior raw evals were neither recopied nor rerun.

## Source and custody

Frozen experiment identity from queue command: `f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d`. Freshly captured remote memory_dose definitions SHA256 `ab98329c433cb085cd53e1c766db350f1bb0fe2efb9181e24a3678c0d31a76e3` exactly matches the frozen analyzer's definitions. Analyzer SHA256 `e1327b3d2fdc060e33aad3d088beada167226437a9b1e6f28b819c6b5959eea9`. Captured both runbooks and recorded all file identities. Bank0 eval/train/receipt and all required source inputs are self-contained. Bank1 fit metadata matches its receipt corpus fields; full bank1 evaluation/source analysis was not performed.

All25 remote captured files passed size/SHA256 checks and remained stable during reading. `CAPTURE_MANIFEST.json` records exact original paths, times, hashes, and any bounded-log byte offset. Two adapter binaries are excluded from the archive but hashed and confirmed present at their original node2 paths (80792096 bytes each): bank0 SHA256 `2a638bb476071bc21127d94735718cfc4e3936d49eb961100606e3eef19fd18d`; bank1 SHA256 `f3f8a3755ee4578670bf91f5bab6dfd47eb599dec50c097d2efba9e8bba8fed5`. Raw archive is sufficient for this bank0 CPU analysis, not new model inference. Base weights, runtime environment and excluded adapters are not bundled. Retention is observed at capture, not guaranteed indefinitely.

Label remains **SYNTHETIC_DIAGNOSTIC_NOT_CLEAN_LINEAGE**: compatible frozen material is not clean ancestry, child-only unrestricted lineage, H1/H2 evidence, parenting effect, or scientific campaign completion. Profile completion is not a fit; fit completion is not evaluation completion; G9 failure is not a runtime failure. Original failed attempts are untouched.

`STATUS_SNAPSHOT.json` transcribes the single status observation; raw queue job/script/log are captured separately. `capture_remote.py` and `CAPTURE_COMMAND.json` retain the exact fixed capture program/command. `ANALYSIS_RECEIPT.json`, `ANALYZER_REUSE.json`, `PRIOR_IDENTITY_REFERENCE.json`, `VALIDATION.json`, and `analysis.json` preserve provenance and exact results. No notebook, Git, source, original evidence, remote writes, launches, stops, reruns, or external fetches. No further remote inspection is planned for this task.

After extraction into a new directory, run `sha256sum -c SHA256SUMS` from the capsule root. To rerun the CPU-only analysis with a relocated root, use the bundled analyzer with `--entry run/eval/bank0__CF_r16_b__across__sleep4__r8__lam1.json run/adapters/bank0/CF_r16_b/across/sleep4/r8/train_meta.json run/seed_run_receipt.json`. Preserve the raw archive with its checksum; adjacent JSON alone is not raw custody.
