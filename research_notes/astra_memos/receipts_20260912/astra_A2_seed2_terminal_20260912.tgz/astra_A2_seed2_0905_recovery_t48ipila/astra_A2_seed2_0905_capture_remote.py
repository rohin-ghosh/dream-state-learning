import datetime
import hashlib
import io
import json
from pathlib import Path
import socket
import subprocess
import sys
import tarfile

home = Path.home()
run_name = 'astra_A2_memory_dose_D32_CF_r16_b_ts2_20260912_attempt2'
run = home / 'v6_out' / run_name
source = home / 'astra_sources/f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d'
observed = datetime.datetime.now(datetime.timezone.utc).isoformat()
process_argv = ['ps', '-eo', 'pid,ppid,lstart,stat,args', '--no-headers']
process = subprocess.run(process_argv, capture_output=True, text=True)
process_lines = process.stdout.splitlines()
related = {3560937}
for iteration in range(12):
    discovered = {int(line.split(None, 2)[0]) for line in process_lines
                  if len(line.split(None, 2)) == 3 and int(line.split(None, 2)[1]) in related}
    if discovered <= related:
        break
    related.update(discovered)
selected_processes = [line for line in process_lines if int(line.split(None, 1)[0]) in related]
queue_files = sorted((home / 'queue').glob('*/0052_' + run_name + '.job'))
markers = sorted(run.glob('STAGE*'))
banks = []
for bank in range(3):
    adapter = run / f'adapters/bank{bank}/CF_r16_b/across/sleep4/r8'
    evaluation = run / f'eval/bank{bank}__CF_r16_b__across__sleep4__r8__lam1.json'
    banks.append({'bank': bank, 'fit_done': (adapter / 'DONE').is_file(),
                  'train_meta_exists': (adapter / 'train_meta.json').is_file(),
                  'eval_exists': evaluation.is_file(), 'eval_path': str(evaluation)})
rc_path = home / 'queue/logs' / (run_name + '.rc')
status = {'observed_utc': observed, 'hostname': socket.gethostname(), 'node': 'node2',
          'run': str(run), 'source': str(source), 'source_commit': source.name,
          'queue_pid': 3560937, 'queue_files': [str(path) for path in queue_files],
          'process_command': process_argv, 'process_returncode': process.returncode,
          'process_stderr': process.stderr, 'process_rows': selected_processes,
          'queue_pid_present': any(int(line.split(None, 1)[0]) == 3560937 for line in selected_processes),
          'markers': [path.name for path in markers], 'banks': banks,
          'queue_rc': rc_path.read_text() if rc_path.is_file() else None,
          'scope': 'Single status observation; fixed capture of existing files; no polling or remote writes.'}
archive = tarfile.open(fileobj=sys.stdout.buffer, mode='w|')
inventory = []

def add(relative, data):
    info = tarfile.TarInfo(relative)
    info.size = len(data)
    archive.addfile(info, io.BytesIO(data))

def capture(path, relative, hash_only=False):
    if not path.is_file():
        inventory.append({'remote_path': str(path), 'capsule_path': relative, 'missing': True})
        return
    before = path.stat()
    digest = hashlib.sha256()
    if hash_only:
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                digest.update(chunk)
    else:
        data = path.read_bytes()
        digest.update(data)
        add(relative, data)
    after = path.stat()
    inventory.append({'remote_path': str(path), 'capsule_path': relative,
                      'bytes': before.st_size, 'mtime_ns': before.st_mtime_ns,
                      'sha256': digest.hexdigest(), 'hash_only': hash_only,
                      'stable_during_read': (before.st_size, before.st_mtime_ns, before.st_ino)
                      == (after.st_size, after.st_mtime_ns, after.st_ino)})

add('STATUS_SNAPSHOT.json', (json.dumps(status, indent=2) + '\n').encode())
for relative in ['manifest.json', 'seed_run_receipt.json', 'distractor.json']:
    capture(run / relative, 'run/' + relative)
for bank_status in banks:
    bank = bank_status['bank']
    capture(run / f'banks/bank{bank}.json', f'run/banks/bank{bank}.json')
    for filename in ['corpus.json', 'generations.json']:
        relative = f'corpora/bank{bank}/CF_r16_b/across/sleep4/{filename}'
        capture(run / relative, 'run/' + relative)
    if bank_status['eval_exists']:
        evaluation = Path(bank_status['eval_path'])
        capture(evaluation, 'run/' + evaluation.relative_to(run).as_posix())
    adapter = run / f'adapters/bank{bank}/CF_r16_b/across/sleep4/r8'
    for path in sorted(adapter.rglob('*')):
        if path.is_file():
            capture(path, 'run/' + path.relative_to(run).as_posix(),
                    hash_only=path.suffix in {'.safetensors', '.bin', '.pt', '.pth'})
for path in markers + sorted((run / 'logs').glob('*')):
    if path.is_file():
        capture(path, 'run/' + path.relative_to(run).as_posix())
for path in queue_files:
    capture(path, 'queue/' + path.relative_to(home / 'queue').as_posix())
for suffix in ['sh', 'out', 'pid', 'rc']:
    path = home / 'queue/logs' / (run_name + '.' + suffix)
    capture(path, 'queue/logs/' + path.name)
for relative in ['organism_v6/memory_dose.py', 'gpu/memory_dose_childframes.sh', 'gpu/memory_dose_frames.sh']:
    capture(source / relative, 'experiment_source/' + relative)
add('CAPTURE_MANIFEST.json', (json.dumps({'observed_utc': observed,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': inventory}, indent=2) + '\n').encode())
archive.close()
