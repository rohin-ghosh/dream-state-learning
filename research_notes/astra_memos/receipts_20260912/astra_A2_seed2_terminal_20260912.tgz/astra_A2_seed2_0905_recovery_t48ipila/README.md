# A2 seed2 — terminal fits-stage recovery

**Observed 2026-09-12 09:07:22.691264 UTC on node2 (`ipp2-ovx-p2-08`).** The `0905` filename is the requested task label, not the observation time. Queue0052 is in `queue/done`, PID3560937 is absent, and exact queue RC is `0`. Queue started **07:41:12 UTC**, finished **09:04:34 UTC**. `STAGE_CF_FITS_DONE` exists; log ends `MEMORY_DOSE_CHILDFRAMES_DONE step=fits` at **09:04:30 UTC**. No report-stage `STAGE_CF_DONE` exists: this is successful terminal **fits/evals**, not whole-campaign/report completion.

- Run: `/localhome/local-rohing/v6_out/astra_A2_memory_dose_D32_CF_r16_b_ts2_20260912_attempt2`.
- Frozen experiment source: `/localhome/local-rohing/astra_sources/f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d` (commit label `f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d`). Captured definitions and both runbooks match the prior frozen capsule byte-for-byte; no Git operation was used.
- Configuration: `CF_r16_b`, optimizer seed2, source-bank seed0, banks0/1/2, rank8, lambda1; frozen Qwen2.5-7B-Instruct base, 3 epochs, lr0.0001. Synthetic diagnostic only.

## Exact bank outcomes

| Bank | TRAIN_DONE UTC | EVAL_DONE UTC | Mean I_d_frame | Within-fit/bank 95% interval | Frame spill | G9 |
|---|---|---|---|---|---|---|
| 0 | 08:05:22 | 08:08:43 | 1.184902794133669 | [0.736801601373312, 1.8112251421790742] | 0.3231037216369375 | FAIL |
| 1 | 08:32:58 | 08:36:17 | 0.7435414468523857 | [0.18527321253195464, 1.3734456861839741] | 0.29437713366212465 | FAIL |
| 2 | 09:01:10 | 09:04:30 | 1.9323354878015453 | [1.0418108995978572, 2.9366826704478126] | 0.3564715626294083 | FAIL |

**Denominators, separately for every bank:** 1313 eval cues; 64 owners (16 each at doses0/1/4/16); 16 paired dose16 owners in the interval. Spill is the equally weighted mean of three component means: 48 similar-exposed owners, 16 unexposed owners, 48 bicycle-exposed owners. Dose16 frame/similar/bicycle summaries each have 16 cues and 16 valid OFF / 16 valid ON controls. All3 source-compatible; no missing controls or zero-imputation.

Unchanged analyzer uses 2000 paired-owner bootstrap resamples, bootstrap seed0, 95% percentile interval. G9 requires lower bound >0 AND spill <=0.03; all three fail only the spill condition. No tuning, new thresholds, pooling, causal comparison or optimizer-seed uncertainty estimate. `frame_similar` is an unseen look-alike, not an exposed-partner swapped-ID test.

| Bank | Similar-exposed spill (n48) | Unexposed spill (n16) | Bicycle-exposed spill (n48) |
|---|---|---|---|
| 0 | 0.3374050732221309 | 0.2607534038497642 | 0.37115268783891736 |
| 1 | 0.2871374975968861 | 0.2757106031790842 | 0.3202833002104036 |
| 2 | 0.3810867989859782 | 0.24544060744205792 | 0.4428872814601889 |

Bank0 raw eval, metrics and input identities exactly match the 08:34 capsule. Increment since that snapshot: **two newly evaluated bank artifacts (bank1/2), one newly completed fit (bank2), zero new optimizer-seed configurations**. These are three bank artifacts from one A2/optimizer-seed2 configuration, not three independent seeds. Label remains `SYNTHETIC_DIAGNOSTIC_NOT_CLEAN_LINEAGE`; no H1/H2 or parenting claim.

## Receipts and custody

- Capsule: `/tmp/astra_A2_seed2_0905_recovery_t48ipila`. Full eval JSONs, source inputs/corpora, train metadata/DONE, all run logs, queue job/launch/stdout/PID/RC, stage marker and frozen source/analyzer included. Full dose16 conditional probabilities, masses and valid counts remain in `analysis.json`; exact fit steps/tokens/loss/wall times remain in each `train_meta.json`.
- `CAPTURE_COMMAND.json` contains the exact wrapper argv and embedded read-only script; `STATUS_SNAPSHOT.json` records the exact `ps` command/result. One status observation only. `CAPTURE_MANIFEST.json` binds 47 copied remote files and 3 hash-only adapter identities; all50 stable during read. Adapter binaries are omitted, with original paths/bytes/SHA256 preserved.
- `ANALYSIS_RECEIPT.json` contains the exact three-entry local analyzer command: exit0, empty stderr. Unchanged analyzer SHA256 `e1327b3d2fdc060e33aad3d088beada167226437a9b1e6f28b819c6b5959eea9`; definitions SHA256 `ab98329c433cb085cd53e1c766db350f1bb0fe2efb9181e24a3678c0d31a76e3`.
- Analysis output SHA256: `ef1af0ff7170f5ede894ae09e3d5bb0833501239e7fa179880453812a322853f`.
- Prior archive SHA256 remains `80a30ec80cfb53e856be00e7ae82f4a4a5aa6bdc3c56156ca264e32dd97536d8`; all44 prior capsule files unchanged before/after; all43 prior manifest payload hashes verified. Prior source and artifacts were never overwritten.
- Applicable supplied/local AGENTS instructions, launch-prompt invariants, prior A2 memo and existing capture/analyzer scripts were read. Separate read-only remote instruction discovery returned no applicable AGENTS files. No repository edit, Git operation, remote write, GPU launch/kill, polling loop, curl or wget.
