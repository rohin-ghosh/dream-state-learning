#!/bin/bash
# queue_runner job astra_A2_memory_dose_D32_CF_r16_b_ts2_20260912_attempt2 launched 2026-09-12T07:41:12Z on GPU(s) 1
cd /localhome/local-rohing/dream-state || exit 97
export CUDA_VISIBLE_DEVICES=1 GPU=1 GPUS=1
PYTHONDONTWRITEBYTECODE=1 REPO='/localhome/local-rohing/astra_sources/f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d' RUN='/localhome/local-rohing/v6_out/astra_A2_memory_dose_D32_CF_r16_b_ts2_20260912_attempt2' SEED=2 MODEL=hf F_RANK=8 CF_CELLS=CF_r16_b F_BANKS='0 1 2' F_TOKEN_BUDGET=250000 MAX_FIT_MIN=35 bash '/localhome/local-rohing/astra_sources/f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d/gpu/memory_dose_childframes.sh' 1 fits
