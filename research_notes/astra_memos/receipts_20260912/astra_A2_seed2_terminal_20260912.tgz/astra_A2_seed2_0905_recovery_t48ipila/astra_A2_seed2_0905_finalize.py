from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

root = Path('/tmp/astra_A2_seed2_0905_recovery_t48ipila')
repo = Path('/data/home/rohing/dream-state')
prior = Path('/tmp/astra_A2_seed2_terminal_20260912')
report = Path('/tmp/astra_A2_seed2_0905_snapshot.md')
assert not report.exists()
archive_path = root.with_suffix('.tgz')
assert not archive_path.exists()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(name, value):
    with (root / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

shutil.copyfile(__file__, root / Path(__file__).name)
for relative in ['AGENTS.md', 'gpu/ovx_ssh.sh',
                 'research_notes/astra_memos/receipts_20260912/astra_A2_seed2_snapshot_20260912T083402Z.md']:
    target = root / 'local_reference' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / relative, target)
analysis = json.loads((root / 'analysis.json').read_text())
previous = json.loads((root / 'PRIOR_BANK0_ANALYSIS.json').read_text())['rows'][0]
status = json.loads((root / 'STATUS_SNAPSHOT.json').read_text())
manifest = json.loads((root / 'CAPTURE_MANIFEST.json').read_text())
assert analysis['counts'] == {'binding_available': 3, 'compatible_source_entries': 3, 'completed_fits': 3, 'entries': 3}
assert all(not entry.get('missing') and entry['stable_during_read'] for entry in manifest['files'])
source_checks = []
for path in (root / 'experiment_source').rglob('*'):
    if path.is_file():
        old_path = prior / path.relative_to(root)
        assert digest(path) == digest(old_path)
        source_checks.append({'capsule_path': path.relative_to(root).as_posix(), 'sha256': digest(path), 'matches_prior_frozen_source': True})
assert digest(root / 'experiment_source/organism_v6/memory_dose.py') == analysis['definitions_sha256']
for field in ['binding', 'dose16', 'source_hash_compatibility', 'eval_cue_count']:
    assert analysis['rows'][0][field] == previous[field]
assert digest(root / 'run/eval/bank0__CF_r16_b__across__sleep4__r8__lam1.json') == digest(prior / 'run/eval/bank0__CF_r16_b__across__sleep4__r8__lam1.json')
prior_verified = 0
for line in (prior / 'SHA256SUMS').read_text().splitlines():
    expected, relative = line.split('  ', 1)
    assert digest(prior / relative) == expected
    prior_verified += 1
denominators = []
for row in analysis['rows']:
    bank = row['bank']
    roster = json.loads((root / f'run/banks/bank{bank}.json').read_text())['owners']
    doses = Counter(owner['dose'] for owner in roster)
    assert doses == {0: 16, 1: 16, 4: 16, 16: 16}
    assert row['binding']['unavailable'] == []
    denominators.append({'bank': bank, 'owners': len(roster), 'owners_by_dose': dict(doses),
        'paired_dose16_owners': row['binding']['I_d_frame']['n'],
        'spill_unexposed_n': doses[0], 'spill_similar_exposed_n': sum(value for dose, value in doses.items() if dose > 0),
        'spill_bicycle_exposed_n': sum(value for dose, value in doses.items() if dose > 0),
        'spill_component_mean_count': 3,
        'dose16_valid_counts': {kind: {key: value for key, value in values.items() if key.endswith('count')}
                                for kind, values in row['dose16'].items()}})
write_json('DENOMINATORS.json', denominators)
write_json('SOURCE_AND_PRIOR_CHECKS.json', {'source_checks': source_checks, 'prior_manifest_payloads_verified': prior_verified,
    'bank0_eval_bytes_unchanged': True, 'bank0_metrics_and_input_hashes_unchanged': True})
lines = [
    '# A2 seed2 — terminal fits-stage recovery', '',
    '**Observed 2026-09-12 09:07:22.691264 UTC on node2 (`ipp2-ovx-p2-08`).** The `0905` filename is the requested task label, not the observation time. Queue0052 is in `queue/done`, PID3560937 is absent, and exact queue RC is `0`. Queue started **07:41:12 UTC**, finished **09:04:34 UTC**. `STAGE_CF_FITS_DONE` exists; log ends `MEMORY_DOSE_CHILDFRAMES_DONE step=fits` at **09:04:30 UTC**. No report-stage `STAGE_CF_DONE` exists: this is successful terminal **fits/evals**, not whole-campaign/report completion.', '',
    f'- Run: `{status["run"]}`.',
    f'- Frozen experiment source: `{status["source"]}` (commit label `{status["source_commit"]}`). Captured definitions and both runbooks match the prior frozen capsule byte-for-byte; no Git operation was used.',
    '- Configuration: `CF_r16_b`, optimizer seed2, source-bank seed0, banks0/1/2, rank8, lambda1; frozen Qwen2.5-7B-Instruct base, 3 epochs, lr0.0001. Synthetic diagnostic only.', '',
    '## Exact bank outcomes', '',
    '| Bank | TRAIN_DONE UTC | EVAL_DONE UTC | Mean I_d_frame | Within-fit/bank 95% interval | Frame spill | G9 |',
    '|---|---|---|---|---|---|---|']
times = [('08:05:22', '08:08:43'), ('08:32:58', '08:36:17'), ('09:01:10', '09:04:30')]
for row, (train_time, eval_time) in zip(analysis['rows'], times):
    binding = row['binding']
    interval = binding['I_d_frame']
    lines.append(f'| {row["bank"]} | {train_time} | {eval_time} | {interval["mean"]} | [{interval["lo"]}, {interval["hi"]}] | {binding["frame_spill"]} | FAIL |')
lines.extend(['',
    '**Denominators, separately for every bank:** 1313 eval cues; 64 owners (16 each at doses0/1/4/16); 16 paired dose16 owners in the interval. Spill is the equally weighted mean of three component means: 48 similar-exposed owners, 16 unexposed owners, 48 bicycle-exposed owners. Dose16 frame/similar/bicycle summaries each have 16 cues and 16 valid OFF / 16 valid ON controls. All3 source-compatible; no missing controls or zero-imputation.', '',
    'Unchanged analyzer uses 2000 paired-owner bootstrap resamples, bootstrap seed0, 95% percentile interval. G9 requires lower bound >0 AND spill <=0.03; all three fail only the spill condition. No tuning, new thresholds, pooling, causal comparison or optimizer-seed uncertainty estimate. `frame_similar` is an unseen look-alike, not an exposed-partner swapped-ID test.', '',
    '| Bank | Similar-exposed spill (n48) | Unexposed spill (n16) | Bicycle-exposed spill (n48) |',
    '|---|---|---|---|'])
for row in analysis['rows']:
    parts = row['binding']['spill_parts']
    lines.append(f'| {row["bank"]} | {parts["similar_exposed"]} | {parts["unexposed"]} | {parts["bicycle_exposed"]} |')
lines.extend(['',
    'Bank0 raw eval, metrics and input identities exactly match the 08:34 capsule. Increment since that snapshot: **two newly evaluated bank artifacts (bank1/2), one newly completed fit (bank2), zero new optimizer-seed configurations**. These are three bank artifacts from one A2/optimizer-seed2 configuration, not three independent seeds. Label remains `SYNTHETIC_DIAGNOSTIC_NOT_CLEAN_LINEAGE`; no H1/H2 or parenting claim.', '',
    '## Receipts and custody', '',
    f'- Capsule: `{root}`. Full eval JSONs, source inputs/corpora, train metadata/DONE, all run logs, queue job/launch/stdout/PID/RC, stage marker and frozen source/analyzer included. Full dose16 conditional probabilities, masses and valid counts remain in `analysis.json`; exact fit steps/tokens/loss/wall times remain in each `train_meta.json`.',
    '- `CAPTURE_COMMAND.json` contains the exact wrapper argv and embedded read-only script; `STATUS_SNAPSHOT.json` records the exact `ps` command/result. One status observation only. `CAPTURE_MANIFEST.json` binds 47 copied remote files and 3 hash-only adapter identities; all50 stable during read. Adapter binaries are omitted, with original paths/bytes/SHA256 preserved.',
    '- `ANALYSIS_RECEIPT.json` contains the exact three-entry local analyzer command: exit0, empty stderr. Unchanged analyzer SHA256 `e1327b3d2fdc060e33aad3d088beada167226437a9b1e6f28b819c6b5959eea9`; definitions SHA256 `ab98329c433cb085cd53e1c766db350f1bb0fe2efb9181e24a3678c0d31a76e3`.',
    f'- Analysis output SHA256: `{digest(root / "analysis.json")}`.',
    '- Prior archive SHA256 remains `80a30ec80cfb53e856be00e7ae82f4a4a5aa6bdc3c56156ca264e32dd97536d8`; all44 prior capsule files unchanged before/after; all43 prior manifest payload hashes verified. Prior source and artifacts were never overwritten.',
    '- Applicable supplied/local AGENTS instructions, launch-prompt invariants, prior A2 memo and existing capture/analyzer scripts were read. Separate read-only remote instruction discovery returned no applicable AGENTS files. No repository edit, Git operation, remote write, GPU launch/kill, polling loop, curl or wget.',
])
body = '\n'.join(lines) + '\n'
with (root / 'README.md').open('x') as stream:
    stream.write(body)
payloads = [path for path in sorted(root.rglob('*')) if path.is_file()]
with (root / 'SHA256SUMS').open('x') as stream:
    for path in payloads:
        stream.write(f'{digest(path)}  {path.relative_to(root).as_posix()}\n')
with tarfile.open(archive_path, 'x:gz') as archive:
    archive.add(root, arcname=root.name)
expected = {path.relative_to(root).as_posix(): digest(path) for path in payloads + [root / 'SHA256SUMS']}
verified = 0
with tarfile.open(archive_path, 'r:gz') as archive:
    for member in archive.getmembers():
        if member.isfile():
            relative = Path(member.name).relative_to(root.name).as_posix()
            assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == expected[relative]
            verified += 1
assert verified == len(expected)
archive_sha = digest(archive_path)
with Path(str(archive_path) + '.sha256').open('x') as stream:
    stream.write(f'{archive_sha}  {archive_path.name}\n')
with report.open('x') as stream:
    stream.write(body + f'\n- Raw/source archive: `{archive_path}` ({archive_path.stat().st_size} bytes); **SHA256 `{archive_sha}`**. Verified {verified} archived file hashes including `SHA256SUMS`.\n')
with Path(str(report) + '.sha256').open('x') as stream:
    stream.write(f'{digest(report)}  {report.name}\n')
print(json.dumps({'report': str(report), 'archive': str(archive_path), 'archive_sha256': archive_sha,
                  'archive_bytes': archive_path.stat().st_size, 'verified_archive_files': verified,
                  'report_sha256': digest(report)}, indent=2))
