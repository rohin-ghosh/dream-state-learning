"""Verify the capsule and join both actual 64-record sets by pair_id."""
from collections import Counter, defaultdict
import hashlib
import inspect
import json
from pathlib import Path
import sys


root = Path(__file__).resolve().parents[1]
remote = root / "remote"
home = remote / "localhome/local-rohing"
grounded = home / "astra_diagnostics/astra_oracle_grounded_copy_20260912_attempt1"
previous = home / "astra_diagnostics/astra_oracle_lookup_20260912_attempt1"
source = home / "astra_sources/bb51da513a36fb2c0782d423870f1e88041f8076"
sys.path.insert(0, str(source))
from organism_v6 import multikey_writer_gateway_simple as w0


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


inventory = load(root / "audit/remote_inventory.json")
for name, expected in inventory["files"].items():
    path = remote / name.lstrip("/")
    assert path.stat().st_size == expected["size"] and digest(path) == expected["sha256"], name
parsed_source_hash = hashlib.sha256(inspect.getsource(w0.parse_output).encode()).hexdigest()
for name, run in (("grounded", grounded), ("previous", previous)):
    manifest = load(run / "manifest.json")
    assert parsed_source_hash == manifest["sources"]["calibration"]["strict_parser_sha256"]
    seal = load(run / "LOOKUP_SEAL.json")
    actual = {path.relative_to(run).as_posix(): digest(path) for path in run.rglob("*")
              if path.is_file() and path.name != "LOOKUP_SEAL.json"}
    assert actual == seal["files"]
    assert load(root / f"audit/{name}_original_replay.json") == load(run / "report.json")
    resource = load(run / "RESOURCE.json")
    assert digest(remote / resource["log_path"].lstrip("/")) == resource["log_sha256"]

new_requests = {row["pair_id"]: row for row in load(grounded / "requests.json")}
old_requests = {row["pair_id"]: row for row in load(previous / "requests.json")}
assert len(new_requests) == len(old_requests) == 64 and set(new_requests) == set(old_requests)
assert load(grounded / "manifest.json")["input_pins"] == load(previous / "manifest.json")["input_pins"]
literal = ("Use the action table as the source of truth. For the exact tool and mode in the task, "
           "copy the ACT value after -> from its matching row.")
excluded = {"request_id", "prompt", "rendered_prompt", "prompt_input_ids", "condition",
            "instruction_variant", "instruction_text"}
cells = {name: defaultdict(Counter) for name in ("previous", "grounded")}
histograms = {name: Counter() for name in cells}
totals = {name: Counter() for name in cells}
transitions = {metric: Counter() for metric in ("correct", "valid", "truncated", "multiple")}
paired_rows = []
for pair_id, new in new_requests.items():
    old = old_requests[pair_id]
    assert {key: value for key, value in new.items() if key not in excluded} == {
        key: value for key, value in old.items() if key not in excluded}
    assert new["prompt"] == literal + "\n" + old["prompt"]
    assert new["instruction_variant"] == "grounded_copy"
    joined = dict(pair_id=pair_id, root=new["root"], mapping=new["mapping"], tool=new["tool"],
                  mode=new["mode"], expected=new["expected"], held_index=new["held_index"])
    for name, run, request in (("previous", previous, old), ("grounded", grounded, new)):
        record = load(run / (request["request_id"] + ".json"))
        assert record["request_id"] == request["request_id"]
        parsed = w0.parse_output(record["text"], record["truncated"])
        status = dict(correct=parsed["action"] == request["expected"], valid=parsed["action"] is not None,
                      truncated=record["truncated"], multiple=parsed["multiple_ACT"])
        joined[name] = dict(request_id=request["request_id"], raw_text=record["text"],
                            parsed_action=parsed["action"], **status)
        counts = dict(total=1, **{key: int(value) for key, value in status.items()})
        cells[name][f"{request['root']}/{request['mapping']}"].update(counts)
        totals[name].update(counts)
        histograms[name][record["text"]] += 1
        condition = "single_row" if name == "previous" else "single_row_grounded_copy"
        reported = load(run / "report.json")["paired_prompt_ids"][pair_id][condition]
        assert reported == dict(request_id=record["request_id"], **status)
    for metric in transitions:
        transitions[metric][f"{int(joined['previous'][metric])}->{int(joined['grounded'][metric])}"] += 1
    joined["delta"] = {metric: int(joined["grounded"][metric]) - int(joined["previous"][metric]) for metric in transitions}
    paired_rows.append(joined)

for name, run in (("previous", previous), ("grounded", grounded)):
    condition = "single_row" if name == "previous" else "single_row_grounded_copy"
    for cell, counts in cells[name].items():
        assert dict(counts) == load(run / "report.json")["cells"][cell + "/" + condition]

summary = dict(label="EVALUATION_ONLY", clean_lineage=False, official_authentication=False,
    original_replays={"grounded": 0, "previous": 0}, verified_remote_files=len(inventory["files"]),
    matched_pair_ids=64, identical_noninstruction_fields=True, exact_declared_instruction_prefix=True,
    same_local_input_pins=True, counts=totals, cells=cells, raw_output_histograms=histograms,
    paired_transitions=transitions, count_differences={metric: totals["grounded"][metric] - totals["previous"][metric]
                                                      for metric in transitions},
    elapsed_seconds={name: load(run / "RESOURCE.json")["elapsed_seconds"]
                     for name, run in (("previous", previous), ("grounded", grounded))},
    report_sha256={name: digest(run / "report.json") for name, run in (("previous", previous), ("grounded", grounded))},
    seal_sha256={name: digest(run / "LOOKUP_SEAL.json") for name, run in (("previous", previous), ("grounded", grounded))})
analysis = root / "analysis"
analysis.mkdir(exist_ok=False)
for filename, value in (("summary.json", summary), ("paired_actual_records.json", paired_rows)):
    with (analysis / filename).open("x") as output:
        json.dump(value, output, indent=2, sort_keys=True)
        output.write("\n")
print(json.dumps(summary, indent=2, sort_keys=True))
