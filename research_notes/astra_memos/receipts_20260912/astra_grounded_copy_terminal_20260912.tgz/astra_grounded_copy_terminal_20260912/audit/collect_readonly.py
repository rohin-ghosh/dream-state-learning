"""Read original node3 evidence and stream a hash-inventoried tar to stdout."""
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile


def digest(path):
    hashed = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hashed.update(block)
    return hashed.hexdigest()


home = Path.home()
grounded = home / "astra_diagnostics/astra_oracle_grounded_copy_20260912_attempt1"
previous = home / "astra_diagnostics/astra_oracle_lookup_20260912_attempt1"
files = set()
sources = set()
run_roots = set()


def add_tree(root):
    assert root.is_dir(), str(root)
    for path in root.rglob("*"):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        assert not path.is_symlink(), str(path)
        if path.is_file():
            files.add(path)


for root in (grounded, previous):
    spec = json.loads((root / "manifest.json").read_bytes())
    add_tree(root)
    add_tree(Path(spec["log_dir"]))
    run_roots.add(str(root))
    for path, expected in spec["sources"]["calibration"]["files"].items():
        path = Path(path)
        assert digest(path) == expected, str(path)
        sources.add(path.parents[1])
    module = next(Path(path) for path in spec["sources"]["calibration"]["files"]
                  if path.endswith("/organism_v6/writer_interface_calibration.py")).with_name("oracle_lookup_diagnostic.py")
    assert digest(module) == spec["sources"]["module_sha256"]
    cal_root = Path(spec["calibration_root"])
    add_tree(cal_root)
    cal_spec = json.loads((cal_root / "manifest.json").read_bytes())
    add_tree(Path(cal_spec["log_dir"]))
    for path, expected in cal_spec["sources"]["files"].items():
        path = Path(path)
        assert digest(path) == expected
        sources.add(path.parents[1])
    failed_root = Path(spec["failed_w0_root"])
    for name in ("manifest.json", "REAL_EXECUTION_SEAL.json", "report_real.json", "RESOURCE_RECEIPT.json",
                 "launcher.out", "material.json", "requests.json", "tokenizer_preflight.json",
                 "adapter_hashes.json", "PREPARED_SEAL.json"):
        files.add(failed_root / name)

for root in sources:
    add_tree(root / "organism_v6")
    add_tree(root / "tests")
    for pattern in ("AGENTS.md", "CLAUDE.md", "pyproject.toml", "requirements*.txt"):
        files.update(path for path in root.glob(pattern) if path.is_file())

inventory = {}
for path in sorted(files):
    assert path.is_file() and not path.is_symlink(), str(path)
    inventory[str(path)] = dict(sha256=digest(path), size=path.stat().st_size)

with tarfile.open(fileobj=sys.stdout.buffer, mode="w|") as archive:
    for path in sorted(files):
        archive.add(path, arcname="remote/" + str(path).lstrip("/"), recursive=False)
    for path in files:
        assert inventory[str(path)] == dict(sha256=digest(path), size=path.stat().st_size), str(path)
    receipt = json.dumps(dict(files=inventory, original_files_unchanged_during_collection=True,
                             lookup_roots=sorted(run_roots), source_roots=sorted(map(str, sources)),
                             scope="full lookup/calibration artifacts and logs; runtime packages/tests; failed-W0 reference receipts, not adapters"),
                         indent=2, sort_keys=True).encode() + b"\n"
    entry = tarfile.TarInfo("audit/remote_inventory.json")
    entry.size = len(receipt)
    archive.addfile(entry, io.BytesIO(receipt))
