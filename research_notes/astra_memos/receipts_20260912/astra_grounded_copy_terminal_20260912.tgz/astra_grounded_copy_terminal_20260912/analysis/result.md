# Grounded-copy terminal diagnostic — September 12, 2026

## Outcome

**No improvement in correct responses: 32/64 before and after. Valid responses
decreased from 58/64 to 32/64.** These are counts from both actual raw-record
sets joined on all64 pair IDs, not the amended report's historical constants.
The final declared wording diagnostic is complete; park prompt/format search.

Evidence remains EVALUATION_ONLY / DEVELOPMENT_ORACLE_LOOKUP_DIAGNOSTIC,
clean_lineage=false. This is not W0 promotion, oracle qualification, clean
ancestry, training, persistent learning or parenting evidence. Local source/file
hashes do not establish official base authentication.

## Original-source external replays

Both read-only replays exited **0** through the existing gpu/ovx2_ssh.sh wrapper,
using the corresponding retained producer on node3, not the working checkout:

- Grounded source label bb51da513a36fb2c0782d423870f1e88041f8076;
  run /localhome/local-rohing/astra_diagnostics/astra_oracle_grounded_copy_20260912_attempt1.
- Previous source label 35ba8f2c983d9baa99ece979183dceffd3e4e344;
  run /localhome/local-rohing/astra_diagnostics/astra_oracle_lookup_20260912_attempt1.

Each invocation used the retained source_root as PYTHONPATH, the existing
/localhome/local-rohing/v2/venv/bin/python, -B, and the module's replay command.
Bytecode writes were disabled and offline flags set. Captured stdout equals
each copied report exactly. Captured stderr is retained. No source/run files
were rewritten, no GPU call, launch/kill, extra inference, Git or prompt search
was performed during this task.

## Actual per-cell counts

Every row below has denominator16. Truncated and multiple-ACT counts are zero
for every cell in both conditions.

| Root/map | Previous correct | Previous valid | Grounded correct | Grounded valid | Truncated (each arm) | Multiple (each arm) |
|---|---:|---:|---:|---:|---:|---:|
| 0/W+ | 8 | 15 | 8 | 8 | 0 | 0 |
| 0/W- | 8 | 15 | 8 | 8 | 0 | 0 |
| 1/W+ | 8 | 13 | 8 | 8 | 0 | 0 |
| 1/W- | 8 | 15 | 8 | 8 | 0 | 0 |
| Total /64 | 32 | 58 | 32 | 32 | 0 | 0 |

Raw output histogram, preserving exact strings:

| Text | Previous | Grounded |
|---|---:|---:|
| `ACT: a1` | 58 | 32 |
| `ACT: a` | 6 | 1 |
| `ACT: a a` | 0 | 31 |

These malformed outputs are invalid under the unchanged strict parser; none
was reported token-cap-truncated. There were no valid `ACT: a0` outputs.

## Matched differences (all64 actual pairs)

- Correct to correct:32; incorrect to incorrect:32; improvements:0; regressions:0.
- Valid to valid:32; valid to invalid:26; invalid to invalid:6; invalid to valid:0.
- Net correct change:0/64 (0 percentage points).
- Net valid change:-26/64 (-40.625 percentage points).
- Truncation and multiple-ACT flags remain false for all64 pairs.

The join verified identical pair IDs, expected actions, tool/mode, held index,
selected authentic row, question context, historical baseline request ID and
sampling settings. The new user prompt equals the old one plus exactly the
declared grounded-copy instruction and newline. Local model/tokenizer/environment
input pins match across runs. No outputs were used to select rows.

These paired observations support only the descriptive result that this fixed
wording did not increase correct outputs and reduced valid outputs on these
development prompts. They do not establish a general causal mechanism or a
learning result.

## Historical full-table reference (secondary only)

The actual replayed full-table calibration reference is unchanged in both
reports. This is a historical two-factor comparison (table extent and
instruction), not an isolated instruction contrast.

| Root/map | Total | Correct | Valid | Truncated | Multiple |
|---|---:|---:|---:|---:|---:|
| 0/W+ | 16 | 10 | 14 | 0 | 0 |
| 0/W- | 16 | 11 | 16 | 0 | 0 |
| 1/W+ | 16 | 13 | 15 | 0 | 0 |
| 1/W- | 16 | 11 | 16 | 0 | 0 |
| Total | 64 | 45 | 61 | 0 | 0 |

## Runtime and artifact identity

RESOURCE.json records one NVIDIA A40 for each run:

- Grounded elapsed:67.76379839400033 seconds.
- Previous elapsed:67.62631254799999 seconds.

Grounded launch receipt: timeoutPID43674, node3GPU1, September 12, 2026,
09:10:42.187333 UTC. Launch identity is supplied by main's preserved receipt;
resource and original replay evidence establish the terminal artifact status.

```
Grounded report SHA256:
2b734ee22d3763f5ac3120e3dc71d94ccab40e208280ac1be67bd64b370233b1
Grounded LOOKUP_SEAL.json SHA256:
133c821efbf8fe51c0907167a45c6638d33caeaf94bc5bae1abf7b95b133e965
Previous report SHA256:
aa805fe7a15cecc3ec2b99c0cb9faf4477ad414446d3013c20109f091971a241
Previous LOOKUP_SEAL.json SHA256:
7946935035c23e375da59406a3647d369ce3968888d59cc809acc4f9892cc229
```

## Capsule and verification

Directory: /tmp/astra_grounded_copy_terminal_20260912.

Contains complete grounded and previous lookup raw requests/outputs, reports,
seals, manifests, resource/start/worker receipts and all external run logs;
the complete calibration artifacts/logs; original runtime packages/tests for
all three retained producer roots; failed-W0 reference material/requests/seals
and reports (not its adapter weights); main launch/prepare/CPU receipts; both
external replay transcripts; collector/analyzer scripts; and all64 paired
actual records in analysis/paired_actual_records.json.

879 remote files were hashed before and after collection with equality, then
every copied byte was verified against the remote inventory. Both lookup
sealed inventories and worker log hashes also match. The exact original parser
source hash was checked before independently reducing the paired raw outputs.
audit/remote_inventory.json records original absolute paths without rewriting
them. Files are copied under remote/ for transport; external replay was done
at original paths, not by pretending relocated paths were original.

The existing previous capsule was read-only and remains unchanged:
research_notes/astra_memos/receipts_20260912/astra_oracle_lookup_terminal_20260912.tgz
SHA256 2d03417687053731d542f03987c76e8d5bb1b988edbb37091da73bc219dd2b0c.

The archive and its final SHA256 are provided with this report after packaging.
