import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path


def summarize(root):
    root = Path(root)
    report_bytes = (root / "report.json").read_bytes()
    report = json.loads(report_bytes)
    assert report["label"] == "DEVELOPMENT_CALIBRATION"
    assert report["total_requests"] == 320
    assert report["training"] is False and report["clean_lineage"] is False
    totals = defaultdict(lambda: dict(total=0, correct=0, valid=0, truncated=0, multiple=0))
    for name, cell in report["cells"].items():
        root_id, mapping, condition = name.split("/")
        assert root_id in ("0", "1") and mapping in ("W+", "W-")
        assert cell["total"] == 16
        for field in totals[condition]:
            assert type(cell[field]) is int and 0 <= cell[field] <= 16
            totals[condition][field] += cell[field]
    assert len(totals) == 5 and all(cell["total"] == 64 for cell in totals.values())
    resource = json.loads((root / "RESOURCE.json").read_bytes())
    return dict(
        status="COMPLETED_DEVELOPMENT_CALIBRATION",
        report_sha256=hashlib.sha256(report_bytes).hexdigest(),
        condition_totals=dict(totals),
        root_map_cells=report["cells"],
        elapsed_seconds=resource["elapsed_seconds"],
        A40_hours=resource["A40_hours"],
        paired_inputs=64,
        independent_generalization_claim=False,
        interpretation="Descriptive formatting/cap diagnostic on already-inspected material; no training or W0 rescue.",
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run")
    arguments = parser.parse_args()
    print(json.dumps(summarize(arguments.run), indent=2, sort_keys=True))
