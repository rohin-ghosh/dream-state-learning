import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path


def summarize(root):
    root = Path(root)
    report_bytes = (root / "report.json").read_bytes()
    report = json.loads(report_bytes)
    assert report["new_inference_requests"] == report["replayed_baselines"] == 64
    totals = defaultdict(Counter)
    for name, cell in report["cells"].items():
        assert cell["total"] == 16
        totals[name.split("/")[-1]].update(cell)
    assert len(totals) == 2 and all(cell["total"] == 64 for cell in totals.values())
    requests = json.loads((root / "requests.json").read_bytes())
    texts = Counter(json.loads((root / (request["request_id"] + ".json")).read_bytes())["text"]
                    for request in requests)
    resource = json.loads((root / "RESOURCE.json").read_bytes())
    return dict(condition_totals={name: dict(cell) for name, cell in totals.items()},
                root_map_cells=report["cells"], output_text_counts=dict(texts),
                elapsed_seconds=resource["elapsed_seconds"],
                A40_hours=resource["elapsed_seconds"] / 3600,
                report_sha256=hashlib.sha256(report_bytes).hexdigest(),
                scope="Development inference only; historical paired baseline; no writer qualification.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("run")
    arguments = parser.parse_args()
    print(json.dumps(summarize(arguments.run), indent=2, sort_keys=True))
