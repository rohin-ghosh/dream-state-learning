# A1/A2 bank1/2 evidence — 2026-09-12T0800Z

New exclusive capture; node2 reads only. Primary capture `2026-09-12T08:02:26.106129+00:00`–`2026-09-12T08:02:26.353521+00:00`; final progress `2026-09-12T08:04:18.024987+00:00`.

- `runs/`: eight new bank1/2 eval/train-meta/DONE triples, exact run receipts/stage markers, and required source inputs copied from the original capture **only after fresh remote receipt/hash verification**. No new bank0 fit/eval output copies.
- `queue/`: exact scoped terminal/running records and bounded logs/RC/PID files. Four jobs have RC0 and completed banks0–2; A2 attempt2 seed2 remains running without completed bank0 at the final observation.
- `experiment_source/`: exact frozen experiment memory_dose and two runbooks, matched to commit `f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d`.
- `analysis_code/`: unchanged existing analyzer and its dependencies, copied before execution. `analysis.json` contains **12 separate rows**, not pooled estimates; eight new rows plus four verified old-bank0 rows.12 compatible/evaluable; all12 G9-failing. Detailed values are not causal comparisons.
- `ANALYSIS_RECEIPT.json`: exact12-entry argv, bootstrap seed0, code/output hashes, timestamps, runtime, exit0 and stderr hash. `analysis.stderr` is empty. Execute only to a new output name if replaying; never overwrite captured outputs.
- `CAPTURE_MANIFEST.json`, `CAPTURE_COMMAND.json`, `SOURCE_REUSE_RECEIPT.json`, `FINAL_PROGRESS*.json`: exact source/transport/reuse/status custody. `VALIDATION.json` and `SHA256SUMS`: final integrity checks.

**Replay dependency:** full12-entry replay needs `/tmp/astra_seed_bank0_evidence_20260912/` at the original paths, as recorded in the argv. New-bank1/2 entries are self-contained here; all three bank roster files are included because source validation inspects the full roster. Referenced old bank0 result bytes were remotely rechecked, not copied or rewritten.

Report: `/tmp/astra_A1A2_banks_20260912T0800Z.md`. Durable memo: `research_notes/astra_memos/ASTRA_A1A2_BANKS_2026-09-12T080020Z_READONLY.md`; adjacent JSON contains the exact analysis/source-group hashes. No weights, massive logs, external fetches, notebook changes, Git mutation or remote job actions.
