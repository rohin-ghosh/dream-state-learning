<!-- synthetic=true: researcher-planted memory; disposable mechanism test; never merge into a taught lineage -->
# Memory dose test -- cell F_r16k16 (occurrences x frames, K=16 forms x R=16 repeats), arm across, rank 8, lambda 1

SYNTHETIC researcher-planted memory; disposable mechanism test (Astra memo 2, 2026-09-10); never merge into a taught lineage; not autonomous consolidation.

Primary endpoint: held-out paraphrases (p1-p3), no observation in context. term1 = ON-OFF log-odds(a vs b) at the owner's cue; term2 = the same at the matched non-trigger (unseen similar id, same a and b); I_d = term1 - term2; b = the strongest alternative colour under OFF. P = candidate-normalized over the four colours; P raw = the model's raw probability of the planted colour (all surface variants); mass = raw probability of the four colours together. 95% CIs: paired bootstrap over owners, per bank and pooled.

- corpus ordering: **chronological** (prior-first session order as compile_sleep + train_adapter.py; the within-session and across-sleep arms hold the same item set in a different order and were fitted separately)
- colour assignment: random balanced, after the OFF measurement (prior_match=False); OFF-prior bin edges [0.15, 0.35, 0.55]

## Dose response after sleep 4

| bank | dose | n | P raw OFF/ON | P OFF | P ON | dP | term1 (nats) | term2 (nats) | I_d [95% CI] | mass OFF/ON | exact-short dP | exact-ante dP |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.000/0.094 | 0.246 | 0.263 | 0.018 | 1.120 | - | - | 0.003/0.332 | 0.060 | 0.027 |
| bank0 | 1 | 16 | 0.001/0.267 | 0.252 | 0.558 | 0.306 | 6.067 | 2.922 | 3.144 [1.113, 5.450] | 0.005/0.333 | 0.366 | 0.200 |
| bank0 | 4 | 16 | 0.000/0.233 | 0.245 | 0.464 | 0.219 | 4.857 | 1.835 | 3.022 [1.393, 4.680] | 0.011/0.333 | 0.387 | 0.135 |
| bank0 | 16 | 16 | 0.000/0.301 | 0.247 | 0.587 | 0.340 | 7.156 | 4.470 | 2.686 [1.013, 4.582] | 0.003/0.333 | 0.499 | 0.164 |
| pooled | 0 | 16 | 0.000/0.094 | 0.246 | 0.263 | 0.018 | 1.120 | - | - | 0.003/0.332 | 0.060 | 0.027 |
| pooled | 1 | 16 | 0.001/0.267 | 0.252 | 0.558 | 0.306 | 6.067 | 2.922 | 3.144 [1.113, 5.450] | 0.005/0.333 | 0.366 | 0.200 |
| pooled | 4 | 16 | 0.000/0.233 | 0.245 | 0.464 | 0.219 | 4.857 | 1.835 | 3.022 [1.393, 4.680] | 0.011/0.333 | 0.387 | 0.135 |
| pooled | 16 | 16 | 0.000/0.301 | 0.247 | 0.587 | 0.340 | 7.156 | 4.470 | 2.686 [1.013, 4.582] | 0.003/0.333 | 0.499 | 0.164 |

## By pre-registered OFF-prior bin (dose 16; bin = stored pre-assignment OFF prior of the assigned colour, edges [0.15, 0.35, 0.55]; assignment was random balanced)

| bank | OFF-prior bin | n | P raw OFF/ON | P OFF | P ON | dP | I_d [95% CI] |
|---|---|---|---|---|---|---|---|
| bank0 | <0.15 | 8 | 0.000/0.320 | 0.190 | 0.616 | 0.426 | 4.168 [1.203, 7.497] |
| bank0 | 0.15-0.35 | 4 | 0.000/0.328 | 0.170 | 0.714 | 0.544 | 0.433 [-0.027, 0.827] |
| bank0 | 0.35-0.55 | 4 | 0.000/0.235 | 0.436 | 0.401 | -0.036 | 1.975 [0.604, 3.346] |
| bank0 | >=0.55 | 0 | -/- | - | - | - | - |
| pooled | <0.15 | 8 | 0.000/0.320 | 0.190 | 0.616 | 0.426 | 4.168 [1.203, 7.497] |
| pooled | 0.15-0.35 | 4 | 0.000/0.328 | 0.170 | 0.714 | 0.544 | 0.433 [-0.027, 0.827] |
| pooled | 0.35-0.55 | 4 | 0.000/0.235 | 0.436 | 0.401 | -0.036 | 1.975 [0.604, 3.346] |
| pooled | >=0.55 | 0 | -/- | - | - | - | - |

## Controls (exposed owners; absolute normalized-probability shifts)

swapped id = the partner's own fact cue (same dose, different colour) re-read for the OWNER's colour: dP > 0 means the owner's colour bleeds onto another exposed owner's cue (habit signal, gate 0.03); its log-odds(a vs b) is dominated by the partner's own learning and is shown only.

| bank | unexposed |dP| | similar id |dP| | bicycle |dP| | generic car |dP| | swapped dP (owner colour at partner cue) | swapped dlog-odds (shown only) | unrelated shift |
|---|---|---|---|---|---|---|---|
| bank0 | 0.223 | 0.258 | 0.673 | 0.402 | -0.101 | -4.268 | 0.389 |
| pooled | 0.223 | 0.258 | 0.673 | 0.402 | -0.101 | -4.268 | 0.389 |

## I_d by matched non-trigger type (dose 16; term1 minus the ON-OFF log-odds of the same a vs b at the control cue)

| bank | term1 (trigger) | I_d vs similar id (primary) | vs unexposed owner | vs bicycle | vs generic car |
|---|---|---|---|---|---|
| bank0 | 7.156 | 2.686 | 5.831 | -4.709 | 2.866 |
| pooled | 7.156 | 2.686 | 5.831 | -4.709 | 2.866 |

## Training-text fit vs I_d (memo section 1: a large text-fit gain with I_d ~ 0 is storage without extraction)

text-fit gain = per-token log-likelihood gain ON-OFF (nats/token) of the owner's exact training text: the A/B short piece (header + child target) and the C/D antecedent piece (observation -> child target). This is training-text fit, not evidence of retrievable episodic memory.

| bank | dose | short NLL OFF (nats/tok) | short text-fit gain | antecedent NLL OFF | antecedent text-fit gain | I_d | dP |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 2.656 | 1.553 | 4.484 | 1.793 | - | 0.018 |
| bank0 | 1 | 2.804 | 1.827 | 4.455 | 1.746 | 3.144 | 0.306 |
| bank0 | 4 | 2.943 | 1.985 | 4.499 | 1.813 | 3.022 | 0.219 |
| bank0 | 16 | 3.068 | 2.311 | 4.507 | 1.746 | 2.686 | 0.340 |
| pooled | 0 | 2.656 | 1.553 | 4.484 | 1.793 | - | 0.018 |
| pooled | 1 | 2.804 | 1.827 | 4.455 | 1.746 | 3.144 | 0.306 |
| pooled | 4 | 2.943 | 1.985 | 4.499 | 1.813 | 3.022 | 0.219 |
| pooled | 16 | 3.068 | 2.311 | 4.507 | 1.746 | 2.686 | 0.340 |

## Observation in context (before the ~1,024-token distractor; adjacent on a subset; explicit repaint override)

| bank | dose | ctx P OFF | ctx P ON | adjacent OFF/ON | repaint P(new) OFF | repaint P(new) ON | repaint P(old) ON |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 0.562 | 0.763 | 0.500/0.722 | - | - | - |
| bank0 | 1 | 0.562 | 0.793 | 0.500/0.794 | 0.500 | 0.699 | 0.097 |
| bank0 | 4 | 0.562 | 0.798 | 0.500/0.848 | 0.500 | 0.705 | 0.082 |
| bank0 | 16 | 0.578 | 0.796 | 0.500/0.776 | 0.500 | 0.717 | 0.093 |
| pooled | 0 | 0.562 | 0.763 | 0.500/0.722 | - | - | - |
| pooled | 1 | 0.562 | 0.793 | 0.500/0.794 | 0.500 | 0.699 | 0.097 |
| pooled | 4 | 0.562 | 0.798 | 0.500/0.848 | 0.500 | 0.705 | 0.082 |
| pooled | 16 | 0.578 | 0.796 | 0.500/0.776 | 0.500 | 0.717 | 0.093 |

## Calibration subsets (dose 16; the literal 0.6 -> 0.9 test)

- natural 0.55-0.65 OFF-prior subset (pre-registered from the stored OFF distribution): n=2, P OFF=0.555, P ON=0.250
- base-rate prompt subset (dose-16 owners planted with the base colour): n=4, P OFF=1.000, P ON=1.000. The fleet base-rate prompt NAMES the base colour by design (memo fallback: an explicit prior, not a held-out cue); it counts as a 0.6 prior only if its OFF prior sits in [0.55, 0.65].
- G2 evaluated on: **base_rate** -- natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated

## Conditional lessons (nonce tool: action A in mode X, B in mode Y; a=A, b=B; cue ends before the action)

| bank | dose | n | trigger dlo | no-trigger dlo | reversed dlo | interaction (trig-notrig) | selectivity (trig-rev) | exact-cue dlo | P(A|trigger) OFF/ON |
|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 4 | 3.070 | 0.548 | 1.388 | 2.523 | 1.682 | 5.613 | 0.500/0.629 |
| bank0 | 1 | 4 | -5.173 | 1.254 | -5.884 | -6.427 | 0.711 | 13.741 | 0.500/0.289 |
| bank0 | 4 | 4 | 1.849 | -3.519 | -5.360 | 5.368 | 7.209 | 0.646 | 0.500/0.421 |
| bank0 | 16 | 4 | 5.202 | 2.380 | -0.959 | 2.822 | 6.161 | 6.408 | 0.500/0.762 |
| pooled | 0 | 4 | 3.070 | 0.548 | 1.388 | 2.523 | 1.682 | 5.613 | 0.500/0.629 |
| pooled | 1 | 4 | -5.173 | 1.254 | -5.884 | -6.427 | 0.711 | 13.741 | 0.500/0.289 |
| pooled | 4 | 4 | 1.849 | -3.519 | -5.360 | 5.368 | 7.209 | 0.646 | 0.500/0.421 |
| pooled | 16 | 4 | 5.202 | 2.380 | -0.959 | 2.822 | 6.161 | 6.408 | 0.500/0.762 |

## Gates (memo 2.4; pooled banks, sleep 4, dose 16, paraphrases, no context)

| gate | value | threshold | result | detail |
|---|---|---|---|---|
| G1_p_on | 0.587 | 0.800 | FAIL |  |
| G1_d_p | 0.340 | 0.300 | PASS |  |
| G2_prior_subset | 1.000 | 0.850 | n/a | subset=base_rate, n=4, P OFF=1.000; natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated |
| G3_trigger_nats | 7.156 | 1.500 | PASS |  |
| G4_I_d_ci | 2.686 | 0.000 | PASS | CI [1.013, 4.582], n=16 |
| G5_unrelated | 0.389 | 0.030 | FAIL | unexposed=0.223, similar=0.258, bicycle=0.673, generic=0.402 |
| G6_in_context | 0.796 | 0.900 | FAIL | OFF=0.578 |
| G6_repaint | 0.717 | 0.900 | FAIL | OFF=0.500 |
| G7_retention | - | 0.750 | n/a |  |
| G8_dose_trend |  | - | PASS | d0=0.018, d1=0.306, d4=0.219, d16=0.340, saturated_at_4=False |
| G9_mass | 0.333 | >= 0.5 x OFF and >= 0.1 | PASS | OFF=0.003, min per-owner ON=0.000 |
| G9_frame_binding | 0.152 | CI lower bound > 0 and frame spill <= 0.03 | FAIL | CI [-0.024, 0.333], n=16, frame spill=0.037 |
| G10_frame_dose |  | d1 <= d4 <= d16 and d16 - d1 >= 0.1 | FAIL | d0=0.020, d1=0.032, d4=0.034, d16=0.034, rise d1->d16=0.002 |
| G11_abstention |  | unexposed >= 0.5 and bicycle >= 0.5 and dose-16 <= 0.1 (P(abstain) ON) | FAIL | P(abstain) ON: unexposed=0.012, similar=0.012, bicycle=0.017, d16=0.012; OFF: unexposed=0.014, bicycle=0.017, d16=0.012 |

## Interpretation: **rewrite-habit**

- unrelated shift 0.389 > 0.03
- paraphrase gain (dose 16 dP) 0.340; exact-cue gain 0.499; training-text fit gain 2.311 nats/token; unrelated shift 0.389; revisable by present evidence: True; candidate mass intact: True

## Completion-frame retrieval (Rohin 2026-09-11)

Cue = the bare canonical prefix 'Owner {owner}'s car is' (no header, no chat template), candidates the space-prefixed colour tokens. term1 = ON-OFF log-odds(a vs b) at the owner's frame; term2 = the same at the similar unseen id's frame; I_d_frame = term1 - term2 (paired bootstrap over owners). frame spill = mean |dP| over the similar id's frame, the frame at dose-0 owners and the bicycle frame (gate <= 0.03). Reading: **frame-nothing** (frame-binding = G9_frame_binding passed; frame-habit = frame dP > 0.3 but G9_frame_binding failed). abstain = P('not' | prefix), the first token of 'not observed' (SEQ-039): G11_abstention asks >= 0.5 ON at the dose-0 owners' frames and at the bicycle frames and <= 0.1 at the dose-16 owners' frames. Spill keeps its definition; abstention is the intended route to passing it -- a confident colour at an unexposed owner is the failure the 'not observed' negatives (K_neg) target. '-' = the eval carries no p_abstain.

| bank | dose | n | frame P OFF->ON | frame dP | frame term1 (nats) | frame term2 (nats) | I_d_frame [95% CI] | similar-frame |dP| | bicycle-frame |dP| | frame spill | abstain OFF->ON (owner frame) | abstain ON similar | abstain ON bicycle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.240->0.261 | 0.020 | 0.183 | - | - | - | - | 0.037 | 0.014->0.012 | - | - |
| bank0 | 1 | 16 | 0.259->0.292 | 0.032 | 0.308 | 0.174 | 0.134 [-0.022, 0.294] | 0.041 | 0.036 | 0.037 | 0.013->0.012 | 0.012 | 0.018 |
| bank0 | 4 | 16 | 0.252->0.286 | 0.034 | 0.324 | 0.285 | 0.039 [-0.067, 0.139] | 0.040 | 0.032 | 0.037 | 0.012->0.011 | 0.012 | 0.017 |
| bank0 | 16 | 16 | 0.260->0.294 | 0.034 | 0.343 | 0.191 | 0.152 [-0.024, 0.333] | 0.038 | 0.037 | 0.037 | 0.012->0.012 | 0.012 | 0.017 |
| pooled | 0 | 16 | 0.240->0.261 | 0.020 | 0.183 | - | - | - | - | 0.037 | 0.014->0.012 | - | - |
| pooled | 1 | 16 | 0.259->0.292 | 0.032 | 0.308 | 0.174 | 0.134 [-0.022, 0.294] | 0.041 | 0.036 | 0.037 | 0.013->0.012 | 0.012 | 0.018 |
| pooled | 4 | 16 | 0.252->0.286 | 0.034 | 0.324 | 0.285 | 0.039 [-0.067, 0.139] | 0.040 | 0.032 | 0.037 | 0.012->0.011 | 0.012 | 0.017 |
| pooled | 16 | 16 | 0.260->0.294 | 0.034 | 0.343 | 0.191 | 0.152 [-0.024, 0.333] | 0.038 | 0.037 | 0.037 | 0.012->0.012 | 0.012 | 0.017 |
