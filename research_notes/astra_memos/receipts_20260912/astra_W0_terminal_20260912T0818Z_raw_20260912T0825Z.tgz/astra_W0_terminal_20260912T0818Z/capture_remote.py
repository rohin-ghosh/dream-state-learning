import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

home = Path.home()
run = home / 'astra_diagnostics/astra_W0_v10r1_20260912_attempt2'
source = home / 'astra_sources/27743d0a99b827450f794dbe0c1ab45f0b07bd51'
lineage = json.loads((run / 'infrastructure_attempt_lineage.json').read_bytes())
parent = Path(lineage['predecessor_run'])
started = now()
command = [str(home / 'v2/venv/bin/python'), '-B', '-m', 'organism_v6.multikey_writer_gateway_simple', 'replay-real', '--run', str(run)]
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
replay = subprocess.run(command, cwd=source, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
inventory = []
excluded = []
symlinks = []
archive = tarfile.open(fileobj=sys.stdout.buffer, mode='w|')

def add_bytes(name, content):
    info = tarfile.TarInfo(name)
    info.size = len(content)
    info.mode = 0o444
    archive.addfile(info, io.BytesIO(content))

def add_json(name, content):
    add_bytes(name, (json.dumps(content, indent=2, sort_keys=True) + '\n').encode())

roots = [('attempt2', run), ('parent_attempt', parent), ('frozen_source', source)]
for label, root in roots:
    for path in sorted(root.rglob('*')):
        relative = label + '/' + path.relative_to(root).as_posix()
        if path.is_symlink():
            symlinks.append({'path': str(path), 'target': os.readlink(path)})
            continue
        if not path.is_file():
            continue
        before = path.stat()
        weight = path.suffix.lower() in {'.safetensors', '.bin', '.pt', '.pth', '.ckpt', '.onnx', '.gguf'}
        content = None if weight else path.read_bytes()
        digest = sha(path) if weight else hashlib.sha256(content).hexdigest()
        after = path.stat()
        record = {'node': 'node3', 'remote_path': str(path), 'capsule_path': relative, 'bytes': before.st_size, 'sha256': digest, 'mtime_ns': before.st_mtime_ns, 'stable_during_read': (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino), 'excluded_weight': weight}
        inventory.append(record)
        if weight:
            excluded.append(record.copy())
        else:
            add_bytes(relative, content)
for name in ['astra_W0_v10r1_20260912_config.json', 'astra_W0_v10r1_20260912_attempt2_config.json']:
    path = home / 'astra_diagnostics' / name
    if path.is_file():
        content = path.read_bytes()
        relative = 'run_configs/' + name
        add_bytes(relative, content)
        inventory.append({'node': 'node3', 'remote_path': str(path), 'capsule_path': relative, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(), 'excluded_weight': False, 'stable_during_read': True})
seal = json.loads((run / 'REAL_EXECUTION_SEAL.json').read_bytes())
audit = []
for name, expected in seal['files'].items():
    path = run / name
    actual = sha(path) if path.is_file() else None
    audit.append({'relative_path': name, 'expected_sha256': expected, 'actual_sha256': actual, 'bytes': path.stat().st_size if path.is_file() else None, 'matches': actual == expected})
found = {path.relative_to(run).as_posix() for path in run.rglob('*') if path.is_file() and path.name != 'REAL_EXECUTION_SEAL.json'}
for record in excluded:
    path = Path(record['remote_path'])
    record['retained_remote_at_utc'] = now()
    record['retained_remote'] = path.is_file()
    record['retained_sha256'] = sha(path) if path.is_file() else None
    record['retained_hash_matches_capture'] = record['retained_sha256'] == record['sha256']
add_bytes('audit/replay.stdout', replay.stdout)
add_bytes('audit/replay.stderr', replay.stderr)
add_json('audit/replay_command.json', {'node': 'node3', 'command': command, 'cwd': str(source), 'environment_overrides': {key: environment[key] for key in ['PYTHONDONTWRITEBYTECODE', 'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE']}, 'exit_code': replay.returncode, 'capture_started_utc': started, 'capture_finished_utc': now(), 'remote_writes_performed': False})
add_json('audit/remote_inventory.json', inventory)
add_json('audit/excluded_weights.json', excluded)
add_json('audit/seal_audit.json', {'node': 'node3', 'checked': len(audit), 'matching': sum(record['matches'] for record in audit), 'mismatches': [record for record in audit if not record['matches']], 'extra_files': sorted(found - set(seal['files'])), 'missing_files': sorted(set(seal['files']) - found), 'entries': audit, 'capture_finished_utc': now()})
add_json('audit/capture_summary.json', {'node': 'node3', 'started_utc': started, 'finished_utc': now(), 'source_identity': source.name, 'roots': {label: str(root) for label, root in roots}, 'symlinks_not_followed': symlinks, 'parent_terminal_artifacts': {name: (parent / name).is_file() for name in ['REAL_EXECUTION_SEAL.json', 'PREPARED_SEAL.json', 'report_real.json', 'ABORT.json']}, 'remote_writes_performed': False})
archive.close()
