# W0 attempt2 terminal custody capsule — node3

Read-only capture: 2026-09-12 08:22:04–08:22:07 UTC; supplemental local diagnosis and base inventory captured afterward, with individual timestamps. The directory's 0818Z label identifies the requested capsule, not capture time. Frozen source identity: `27743d0a99b827450f794dbe0c1ab45f0b07bd51`. All source bytes are preserved under `frozen_source/`; exact commands, exit codes, inventories and checksums are retained under `audit/` and the capture scripts.

## Terminal distinctions

- Four fits and ten evaluation phases have fourteen raw DONE receipts. The historical launcher receipt still says LAUNCHED_NOT_COMPLETED: completion is grounded in the separate DONE/resource/report artifacts, not the launch label.
- The emitted, unmodified report says ASSAY_INVALID; all four root/map oracle_BA values are zero. This is synthetic researcher-authored material, not child-only corpus, clean lineage, H1/H2 evidence, parent qualification, or a scientific gate pass.
- Actual frozen `replay-real` was executed read-only using node3's recorded venv, with bytecode and external model access disabled. Exit code 2, empty stdout, stderr `NONREPORTABLE_ABORT: sealed bytes changed`. See `audit/replay_command.json` and `audit/replay.stderr`. No forensic reducer recomputation was performed; report mathematics are not newly certified here.
- Independent hashing of all 3161 sealed files: 3160 match, exactly one mismatch, no missing or extra files. `launcher.out` was sealed as empty: expected SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`. Current 6099-byte logger SHA256 is `407af1ff9ab3ca2865744e64155431cb00be8e21ab4025eb2fc4ac4d56bfb999`, identical to current `report_real.json`. This byte equality is observed, not a repaired seal or successful replay.
- No remote writes, resealing, truncation, experiment launch/kill, source changes, external fetches, notebook/SEQ edits, or Git actions occurred.

## Exact seals, reports and resources

| Raw artifact | SHA256 |
|---|---|
| attempt2/PREPARED_SEAL.json | 22bec9b3f191504135d96c957b07a91959d2d3b09d7a42ef00c73e1dd15fa906 |
| attempt2/REAL_EXECUTION_SEAL.json | f75999b705adc3443a7ca5d964a24fb3ae76606c0dfbda87949da78141ca4fd1 |
| attempt2/report_real.json | 407af1ff9ab3ca2865744e64155431cb00be8e21ab4025eb2fc4ac4d56bfb999 |
| attempt2/RESOURCE_RECEIPT.json | 1e45e59b0874397475b3232794bea7e5f8b0595217b0ef36e0bc70b3045cb618 |
| parent_attempt/PREPARED_SEAL.json | 6d09ffadb5ffc10445ab756d58f221752e2840415c2c43b201cf3d0102b8b1b1 |
| parent_attempt/NONREPORTABLE_ABORT.json | 1f818b236d57a649fc8e5811bfb6c0f0e6ef49c4ea0989d1cd9d3bf0f9c277c8 |

The attempt2 resource receipt records 0.47178089486611147 A40-hours, 1698.4112215180012 reserved GPU-seconds, one GPU, four fits, 1024 optimizer steps and fourteen stages. Resource accounting and execution completion do not override assay/replay failure. Both run roots' existing artifacts are preserved. The predecessor attempt is the Python-header infrastructure abort; it has a PREPARED_SEAL and NONREPORTABLE_ABORT, but no report_real or REAL_EXECUTION_SEAL to capture. Its missing artifacts are not invented. Attempt2's W0 seal/report are retained raw for downstream parent-custody purposes without granting qualification.

## Main's supplemental diagnosis (not regenerated)

Exact local file `supplemental/astra_W0_oracle_diagnosis_20260912T0821Z.json` is copied from main's same-named /tmp file, SHA256 `b8e6dd99920058158bcf099a7d36f3e2f80a25c2d1f45ce34f79e91002ef4a9f`. Each of four root/map groups has 64 requests, 64 truncated, zero legal ACT, zero multiple ACT. The file retains four early raw examples. This is main's author-side diagnostic, not independent analysis or successful replay. A separate five-condition inference-only DEVELOPMENT calibration is planned by main; it is not a W0 rerun/rescue and none was launched here.

## Custody and dependencies

Every regular non-weight file from attempt2 and its predecessor, all 36 frozen-source files, and both sibling run configs were copied exactly. Attempt2 includes all 3008 raw output/trace files. `audit/remote_inventory.json` records 3227 remote file identities, four of which are excluded weights; the other 3223 file hashes and lengths are verified locally before archival. No symlinks were encountered in these captured trees. The transport tar retains the same raw capture plus audit outputs; its duplicate contents are intentional custody evidence.

Four adapter binaries (80792096 bytes each) were NOT copied into this capsule/archive. Exact original node3 locations, SHA256 values and post-capture existence/hash checks are in `audit/excluded_weights.json`; all four remained remotely present with matching hashes. Remote retention is confirmed at those timestamps, not a future retention guarantee.

The base/tokenizer snapshot is also not copied: node3 `/localhome/local-rohing/.cache/huggingface/hub/models--Qwen--Qwen2.5-7B-Instruct/snapshots/a09a35458c702b33eeacc393d103063234e8bc28`. `audit/base_snapshot_inventory.json` inventories all 14 local snapshot files (15242807270 bytes), exact resolved locations and freshly read SHA256 hashes; all existed and were stable during reading. No model metadata was fetched externally. Authentication remains UNRESOLVED_LOCAL_HASHES_ONLY.

Other nonbundled runtime dependencies: node3 `/localhome/local-rohing/v2/venv/bin/python` (recorded Python 3.12.3; package versions in both configs), compiler `/usr/bin/x86_64-linux-gnu-gcc-13`, headers under `/usr/include/python3.12`, and protected child/parent/compilergym/pcfl/c11 roots (all config values `/localhome/local-rohing/v6_out`). Environment/native-build receipts are included; these installations and protected trees are not copied. Frozen-source path on node3 is `/localhome/local-rohing/astra_sources/27743d0a99b827450f794dbe0c1ab45f0b07bd51`. Run root is `/localhome/local-rohing/astra_diagnostics/astra_W0_v10r1_20260912_attempt2`.

This is a full non-weight raw-evidence custody archive, not a self-contained executable replay bundle. Missing local weights/runtime dependencies and the original broken seal remain explicit. Raw payloads are preserved verbatim; authored prose uses node labels, not internal hostnames.

## Verification

From this capsule or its extracted archive root, run `sha256sum -c SHA256SUMS`. It covers every payload file except itself. `VALIDATION.json` records remote-to-local hash checks and source-manifest binding. The adjacent repository archive checksum verifies the compressed archive itself; raw evidence must travel with the archive, not just its JSON sidecars. The capsule is made read-only after validation; this is filesystem write-bit freezing, not cryptographic/WORM storage.
