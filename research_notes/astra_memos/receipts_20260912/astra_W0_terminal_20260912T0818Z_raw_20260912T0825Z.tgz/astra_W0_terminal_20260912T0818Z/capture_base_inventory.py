import datetime
import hashlib
import json
from pathlib import Path

run = Path.home() / 'astra_diagnostics/astra_W0_v10r1_20260912_attempt2'
config = json.loads((run / 'manifest.json').read_bytes())['config']
root = Path(config['model_path'])
entries = []
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            digest.update(chunk)
    after = path.stat()
    entries.append({'remote_path': str(path), 'resolved_remote_path': str(path.resolve()), 'bytes': before.st_size, 'sha256': digest.hexdigest(), 'retained_remote': path.is_file(), 'stable_during_read': (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)})
print(json.dumps({'node': 'node3', 'root': str(root), 'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'official_authentication': 'UNRESOLVED_LOCAL_HASHES_ONLY', 'bytes_not_copied': True, 'entries': entries}, indent=2))
