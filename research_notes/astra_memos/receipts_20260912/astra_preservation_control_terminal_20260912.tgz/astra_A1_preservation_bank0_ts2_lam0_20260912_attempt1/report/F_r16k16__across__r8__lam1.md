<!-- synthetic=true: researcher-planted memory; disposable mechanism test; never merge into a taught lineage -->
# Memory dose test -- cell F_r16k16 (occurrences x frames, K=16 forms x R=16 repeats), arm across, rank 8, lambda 1

SYNTHETIC researcher-planted memory; disposable mechanism test (Astra memo 2, 2026-09-10); never merge into a taught lineage; not autonomous consolidation.

Primary endpoint: held-out paraphrases (p1-p3), no observation in context. term1 = ON-OFF log-odds(a vs b) at the owner's cue; term2 = the same at the matched non-trigger (unseen similar id, same a and b); I_d = term1 - term2; b = the strongest alternative colour under OFF. P = candidate-normalized over the four colours; P raw = the model's raw probability of the planted colour (all surface variants); mass = raw probability of the four colours together. 95% CIs: paired bootstrap over owners, per bank and pooled.

- corpus ordering: **chronological** (prior-first session order as compile_sleep + train_adapter.py; the within-session and across-sleep arms hold the same item set in a different order and were fitted separately)
- colour assignment: random balanced, after the OFF measurement (prior_match=False); OFF-prior bin edges [0.15, 0.35, 0.55]

## Dose response after sleep 4

| bank | dose | n | P raw OFF/ON | P OFF | P ON | dP | term1 (nats) | term2 (nats) | I_d [95% CI] | mass OFF/ON | exact-short dP | exact-ante dP |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.000/0.114 | 0.246 | 0.285 | 0.040 | 1.205 | - | - | 0.003/0.325 | 0.083 | -0.005 |
| bank0 | 1 | 16 | 0.001/0.244 | 0.252 | 0.462 | 0.210 | 4.199 | 2.692 | 1.506 [0.427, 2.888] | 0.005/0.328 | 0.499 | 0.129 |
| bank0 | 4 | 16 | 0.000/0.223 | 0.245 | 0.432 | 0.187 | 4.028 | 2.971 | 1.058 [0.479, 1.666] | 0.011/0.326 | 0.427 | 0.021 |
| bank0 | 16 | 16 | 0.000/0.311 | 0.247 | 0.536 | 0.289 | 5.314 | 2.904 | 2.410 [1.394, 3.436] | 0.003/0.331 | 0.649 | 0.187 |
| pooled | 0 | 16 | 0.000/0.114 | 0.246 | 0.285 | 0.040 | 1.205 | - | - | 0.003/0.325 | 0.083 | -0.005 |
| pooled | 1 | 16 | 0.001/0.244 | 0.252 | 0.462 | 0.210 | 4.199 | 2.692 | 1.506 [0.427, 2.888] | 0.005/0.328 | 0.499 | 0.129 |
| pooled | 4 | 16 | 0.000/0.223 | 0.245 | 0.432 | 0.187 | 4.028 | 2.971 | 1.058 [0.479, 1.666] | 0.011/0.326 | 0.427 | 0.021 |
| pooled | 16 | 16 | 0.000/0.311 | 0.247 | 0.536 | 0.289 | 5.314 | 2.904 | 2.410 [1.394, 3.436] | 0.003/0.331 | 0.649 | 0.187 |

## By pre-registered OFF-prior bin (dose 16; bin = stored pre-assignment OFF prior of the assigned colour, edges [0.15, 0.35, 0.55]; assignment was random balanced)

| bank | OFF-prior bin | n | P raw OFF/ON | P OFF | P ON | dP | I_d [95% CI] |
|---|---|---|---|---|---|---|---|
| bank0 | <0.15 | 8 | 0.000/0.331 | 0.190 | 0.702 | 0.511 | 3.147 [1.892, 4.502] |
| bank0 | 0.15-0.35 | 4 | 0.000/0.333 | 0.170 | 0.430 | 0.261 | 1.191 [0.004, 3.005] |
| bank0 | 0.35-0.55 | 4 | 0.000/0.250 | 0.436 | 0.310 | -0.126 | 2.155 [0.272, 4.037] |
| bank0 | >=0.55 | 0 | -/- | - | - | - | - |
| pooled | <0.15 | 8 | 0.000/0.331 | 0.190 | 0.702 | 0.511 | 3.147 [1.892, 4.502] |
| pooled | 0.15-0.35 | 4 | 0.000/0.333 | 0.170 | 0.430 | 0.261 | 1.191 [0.004, 3.005] |
| pooled | 0.35-0.55 | 4 | 0.000/0.250 | 0.436 | 0.310 | -0.126 | 2.155 [0.272, 4.037] |
| pooled | >=0.55 | 0 | -/- | - | - | - | - |

## Controls (exposed owners; absolute normalized-probability shifts)

swapped id = the partner's own fact cue (same dose, different colour) re-read for the OWNER's colour: dP > 0 means the owner's colour bleeds onto another exposed owner's cue (habit signal, gate 0.03); its log-odds(a vs b) is dominated by the partner's own learning and is shown only.

| bank | unexposed |dP| | similar id |dP| | bicycle |dP| | generic car |dP| | swapped dP (owner colour at partner cue) | swapped dlog-odds (shown only) | unrelated shift |
|---|---|---|---|---|---|---|---|
| bank0 | 0.245 | 0.293 | 0.658 | 0.376 | -0.075 | -3.321 | 0.393 |
| pooled | 0.245 | 0.293 | 0.658 | 0.376 | -0.075 | -3.321 | 0.393 |

## I_d by matched non-trigger type (dose 16; term1 minus the ON-OFF log-odds of the same a vs b at the control cue)

| bank | term1 (trigger) | I_d vs similar id (primary) | vs unexposed owner | vs bicycle | vs generic car |
|---|---|---|---|---|---|
| bank0 | 5.314 | 2.410 | 4.582 | -8.629 | 2.145 |
| pooled | 5.314 | 2.410 | 4.582 | -8.629 | 2.145 |

## Training-text fit vs I_d (memo section 1: a large text-fit gain with I_d ~ 0 is storage without extraction)

text-fit gain = per-token log-likelihood gain ON-OFF (nats/token) of the owner's exact training text: the A/B short piece (header + child target) and the C/D antecedent piece (observation -> child target). This is training-text fit, not evidence of retrievable episodic memory.

| bank | dose | short NLL OFF (nats/tok) | short text-fit gain | antecedent NLL OFF | antecedent text-fit gain | I_d | dP |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 2.656 | 1.352 | 4.484 | 3.165 | - | 0.040 |
| bank0 | 1 | 2.804 | 1.618 | 4.455 | 3.268 | 1.506 | 0.210 |
| bank0 | 4 | 2.943 | 1.986 | 4.499 | 3.302 | 1.058 | 0.187 |
| bank0 | 16 | 3.068 | 2.155 | 4.507 | 3.360 | 2.410 | 0.289 |
| pooled | 0 | 2.656 | 1.352 | 4.484 | 3.165 | - | 0.040 |
| pooled | 1 | 2.804 | 1.618 | 4.455 | 3.268 | 1.506 | 0.210 |
| pooled | 4 | 2.943 | 1.986 | 4.499 | 3.302 | 1.058 | 0.187 |
| pooled | 16 | 3.068 | 2.155 | 4.507 | 3.360 | 2.410 | 0.289 |

## Observation in context (before the ~1,024-token distractor; adjacent on a subset; explicit repaint override)

| bank | dose | ctx P OFF | ctx P ON | adjacent OFF/ON | repaint P(new) OFF | repaint P(new) ON | repaint P(old) ON |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 0.562 | 0.580 | 0.500/0.438 | - | - | - |
| bank0 | 1 | 0.562 | 0.580 | 0.500/0.460 | 0.500 | 0.556 | 0.156 |
| bank0 | 4 | 0.562 | 0.589 | 0.500/0.489 | 0.500 | 0.567 | 0.147 |
| bank0 | 16 | 0.578 | 0.582 | 0.500/0.549 | 0.500 | 0.568 | 0.157 |
| pooled | 0 | 0.562 | 0.580 | 0.500/0.438 | - | - | - |
| pooled | 1 | 0.562 | 0.580 | 0.500/0.460 | 0.500 | 0.556 | 0.156 |
| pooled | 4 | 0.562 | 0.589 | 0.500/0.489 | 0.500 | 0.567 | 0.147 |
| pooled | 16 | 0.578 | 0.582 | 0.500/0.549 | 0.500 | 0.568 | 0.157 |

## Calibration subsets (dose 16; the literal 0.6 -> 0.9 test)

- natural 0.55-0.65 OFF-prior subset (pre-registered from the stored OFF distribution): n=2, P OFF=0.555, P ON=0.050
- base-rate prompt subset (dose-16 owners planted with the base colour): n=4, P OFF=1.000, P ON=0.999. The fleet base-rate prompt NAMES the base colour by design (memo fallback: an explicit prior, not a held-out cue); it counts as a 0.6 prior only if its OFF prior sits in [0.55, 0.65].
- G2 evaluated on: **base_rate** -- natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated

## Conditional lessons (nonce tool: action A in mode X, B in mode Y; a=A, b=B; cue ends before the action)

| bank | dose | n | trigger dlo | no-trigger dlo | reversed dlo | interaction (trig-notrig) | selectivity (trig-rev) | exact-cue dlo | P(A|trigger) OFF/ON |
|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 4 | 1.301 | -0.258 | -0.779 | 1.559 | 2.080 | 3.751 | 0.500/0.515 |
| bank0 | 1 | 4 | -2.190 | 2.953 | -2.674 | -5.144 | 0.484 | 16.315 | 0.500/0.477 |
| bank0 | 4 | 4 | 4.580 | 2.305 | -4.855 | 2.275 | 9.435 | 6.985 | 0.500/0.687 |
| bank0 | 16 | 4 | 2.142 | -4.926 | -6.152 | 7.068 | 8.294 | 8.397 | 0.500/0.830 |
| pooled | 0 | 4 | 1.301 | -0.258 | -0.779 | 1.559 | 2.080 | 3.751 | 0.500/0.515 |
| pooled | 1 | 4 | -2.190 | 2.953 | -2.674 | -5.144 | 0.484 | 16.315 | 0.500/0.477 |
| pooled | 4 | 4 | 4.580 | 2.305 | -4.855 | 2.275 | 9.435 | 6.985 | 0.500/0.687 |
| pooled | 16 | 4 | 2.142 | -4.926 | -6.152 | 7.068 | 8.294 | 8.397 | 0.500/0.830 |

## Gates (memo 2.4; pooled banks, sleep 4, dose 16, paraphrases, no context)

| gate | value | threshold | result | detail |
|---|---|---|---|---|
| G1_p_on | 0.536 | 0.800 | FAIL |  |
| G1_d_p | 0.289 | 0.300 | FAIL |  |
| G2_prior_subset | 0.999 | 0.850 | n/a | subset=base_rate, n=4, P OFF=1.000; natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated |
| G3_trigger_nats | 5.314 | 1.500 | PASS |  |
| G4_I_d_ci | 2.410 | 0.000 | PASS | CI [1.394, 3.436], n=16 |
| G5_unrelated | 0.393 | 0.030 | FAIL | unexposed=0.245, similar=0.293, bicycle=0.658, generic=0.376 |
| G6_in_context | 0.582 | 0.900 | FAIL | OFF=0.578 |
| G6_repaint | 0.568 | 0.900 | FAIL | OFF=0.500 |
| G7_retention | - | 0.750 | n/a |  |
| G8_dose_trend |  | - | PASS | d0=0.040, d1=0.210, d4=0.187, d16=0.289, saturated_at_4=False |
| G9_mass | 0.331 | >= 0.5 x OFF and >= 0.1 | PASS | OFF=0.003, min per-owner ON=0.000 |
| G9_frame_binding | 1.921 | CI lower bound > 0 and frame spill <= 0.03 | FAIL | CI [1.203, 2.683], n=16, frame spill=0.416 |
| G10_frame_dose |  | d1 <= d4 <= d16 and d16 - d1 >= 0.1 | FAIL | d0=0.072, d1=0.346, d4=0.279, d16=0.426, rise d1->d16=0.079 |
| G11_abstention |  | unexposed >= 0.5 and bicycle >= 0.5 and dose-16 <= 0.1 (P(abstain) ON) | FAIL | P(abstain) ON: unexposed=0.000, similar=0.000, bicycle=0.000, d16=0.000; OFF: unexposed=0.014, bicycle=0.017, d16=0.012 |

## Interpretation: **rewrite-habit**

- unrelated shift 0.393 > 0.03
- paraphrase gain (dose 16 dP) 0.289; exact-cue gain 0.649; training-text fit gain 3.360 nats/token; unrelated shift 0.393; revisable by present evidence: True; candidate mass intact: True

## Completion-frame retrieval (Rohin 2026-09-11)

Cue = the bare canonical prefix 'Owner {owner}'s car is' (no header, no chat template), candidates the space-prefixed colour tokens. term1 = ON-OFF log-odds(a vs b) at the owner's frame; term2 = the same at the similar unseen id's frame; I_d_frame = term1 - term2 (paired bootstrap over owners). frame spill = mean |dP| over the similar id's frame, the frame at dose-0 owners and the bicycle frame (gate <= 0.03). Reading: **frame-habit** (frame-binding = G9_frame_binding passed; frame-habit = frame dP > 0.3 but G9_frame_binding failed). abstain = P('not' | prefix), the first token of 'not observed' (SEQ-039): G11_abstention asks >= 0.5 ON at the dose-0 owners' frames and at the bicycle frames and <= 0.1 at the dose-16 owners' frames. Spill keeps its definition; abstention is the intended route to passing it -- a confident colour at an unexposed owner is the failure the 'not observed' negatives (K_neg) target. '-' = the eval carries no p_abstain.

| bank | dose | n | frame P OFF->ON | frame dP | frame term1 (nats) | frame term2 (nats) | I_d_frame [95% CI] | similar-frame |dP| | bicycle-frame |dP| | frame spill | abstain OFF->ON (owner frame) | abstain ON similar | abstain ON bicycle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.240->0.313 | 0.072 | 1.358 | - | - | - | - | 0.416 | 0.014->0.000 | - | - |
| bank0 | 1 | 16 | 0.259->0.606 | 0.346 | 3.875 | 2.378 | 1.497 [0.729, 2.338] | 0.455 | 0.543 | 0.416 | 0.013->0.000 | 0.000 | 0.000 |
| bank0 | 4 | 16 | 0.252->0.531 | 0.279 | 3.398 | 2.148 | 1.250 [0.731, 1.851] | 0.398 | 0.482 | 0.416 | 0.012->0.000 | 0.000 | 0.000 |
| bank0 | 16 | 16 | 0.260->0.685 | 0.426 | 4.115 | 2.193 | 1.921 [1.203, 2.683] | 0.398 | 0.501 | 0.416 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 0 | 16 | 0.240->0.313 | 0.072 | 1.358 | - | - | - | - | 0.416 | 0.014->0.000 | - | - |
| pooled | 1 | 16 | 0.259->0.606 | 0.346 | 3.875 | 2.378 | 1.497 [0.729, 2.338] | 0.455 | 0.543 | 0.416 | 0.013->0.000 | 0.000 | 0.000 |
| pooled | 4 | 16 | 0.252->0.531 | 0.279 | 3.398 | 2.148 | 1.250 [0.731, 1.851] | 0.398 | 0.482 | 0.416 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 16 | 16 | 0.260->0.685 | 0.426 | 4.115 | 2.193 | 1.921 [1.203, 2.683] | 0.398 | 0.501 | 0.416 | 0.012->0.000 | 0.000 | 0.000 |
