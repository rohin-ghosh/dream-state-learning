# Fundamental post-training toy positive-control candidate

Status: CANDIDATE_CPU_ONLY. Main's proposal informed by message15, seed 20260912.
This is candidate material, not a scientific ruling or completed substrate.
It tests low-level behavioral adherence, NOT prediction intelligence, parenting
efficacy, H1/H2, or absence of prior exposure. No clean-lineage claim is made.
No sleep, parented life, fitting, model output, tokenizer, or GPU execution.

## Teaching protocol (metadata only, NOT an evaluation prompt)
Teach: compute a correct prediction BEFORE acting. For addition, write PREDICT
then ACT, both with the correct sum. Example: Add 20 and 21 gives
PREDICT: 41
ACT: 41
Control: act correctly, then state the computed result AFTER the action.
The same example gives
ACT: 41
RESULT: 41
This out-of-range illustration is protocol metadata, not a corpus case.
Device questions teach arbitrary logged colors; answer with the recorded color,
or unknown for a device with no recorded color. Both arms teach identical facts.
These instructions and examples are separate metadata: the emitter NEVER adds
them to train/eval contexts. Any later use as training text requires a new audit.

## Fixed construction and future native audit
One local Random(20260912) shuffles lexicographic operand pairs with left <= right
in 0..19. The first 64 are training and next 64 evaluation, disjoint even under
operand reversal. Then shuffle four copies of each color, the combined training
case order, and the combined evaluation order, in that sequence.
Training: 64 arithmetic + 16 identical device QA records per arm.
Evaluation: 64 arithmetic + 32 fresh recall paraphrases + 16 untaught probes.
Unknown means absent from this generated log, not a real-world device property.
Evaluation contexts contain no teaching reminders, examples, or answer facts.
Arithmetic expected sums are task-only answer keys, not mandated response text.

NATIVE_TOKEN_MATCH_PENDING: raw context/response segments only; no token counts,
rendering, truncation, padding, or fitting. Main must audit actual native template,
loss boundaries, special tokens and counts before any model output. If the
default RESULT label differs in counts, select the FIRST globally matching label
in RESULT, COMPUTED_RESULT, RESULT_SUM, COMPUTED order, comparing every paired arithmetic
record, and record the native evidence. All variants truthfully name the sum.
COMPUTED was added after the first native CPU-only audit found no match among
the original three; tokenizer inspection found three pieces, like PREDICT.
No model output informed that preparation amendment. Do not select per case
or use model outputs. If none matches, report unresolved;
do not claim matching or silently alter/pad/truncate material. The helper merely
constructs a requested label; it does not choose, count, render, or authorize it.
