<!-- synthetic=true: researcher-planted memory; disposable mechanism test; never merge into a taught lineage -->
# Memory dose test -- cell F_r16k16 (occurrences x frames, K=16 forms x R=16 repeats), arm across, rank 8, lambda 1

SYNTHETIC researcher-planted memory; disposable mechanism test (Astra memo 2, 2026-09-10); never merge into a taught lineage; not autonomous consolidation.

Primary endpoint: held-out paraphrases (p1-p3), no observation in context. term1 = ON-OFF log-odds(a vs b) at the owner's cue; term2 = the same at the matched non-trigger (unseen similar id, same a and b); I_d = term1 - term2; b = the strongest alternative colour under OFF. P = candidate-normalized over the four colours; P raw = the model's raw probability of the planted colour (all surface variants); mass = raw probability of the four colours together. 95% CIs: paired bootstrap over owners, per bank and pooled.

- corpus ordering: **chronological** (prior-first session order as compile_sleep + train_adapter.py; the within-session and across-sleep arms hold the same item set in a different order and were fitted separately)
- colour assignment: random balanced, after the OFF measurement (prior_match=False); OFF-prior bin edges [0.15, 0.35, 0.55]

## Dose response after sleep 4

| bank | dose | n | P raw OFF/ON | P OFF | P ON | dP | term1 (nats) | term2 (nats) | I_d [95% CI] | mass OFF/ON | exact-short dP | exact-ante dP |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.000/0.018 | 0.246 | 0.242 | -0.004 | 1.228 | - | - | 0.003/0.092 | 0.022 | -0.007 |
| bank0 | 1 | 16 | 0.001/0.028 | 0.252 | 0.245 | -0.007 | 1.254 | 1.350 | -0.096 [-1.010, 0.788] | 0.005/0.113 | -0.017 | -0.007 |
| bank0 | 4 | 16 | 0.000/0.029 | 0.245 | 0.283 | 0.038 | 1.813 | 1.267 | 0.546 [0.067, 1.176] | 0.011/0.090 | -0.024 | -0.010 |
| bank0 | 16 | 16 | 0.000/0.022 | 0.247 | 0.228 | -0.019 | 0.798 | 0.679 | 0.118 [-0.858, 1.061] | 0.003/0.093 | -0.014 | -0.001 |
| pooled | 0 | 16 | 0.000/0.018 | 0.246 | 0.242 | -0.004 | 1.228 | - | - | 0.003/0.092 | 0.022 | -0.007 |
| pooled | 1 | 16 | 0.001/0.028 | 0.252 | 0.245 | -0.007 | 1.254 | 1.350 | -0.096 [-1.010, 0.788] | 0.005/0.113 | -0.017 | -0.007 |
| pooled | 4 | 16 | 0.000/0.029 | 0.245 | 0.283 | 0.038 | 1.813 | 1.267 | 0.546 [0.067, 1.176] | 0.011/0.090 | -0.024 | -0.010 |
| pooled | 16 | 16 | 0.000/0.022 | 0.247 | 0.228 | -0.019 | 0.798 | 0.679 | 0.118 [-0.858, 1.061] | 0.003/0.093 | -0.014 | -0.001 |

## By pre-registered OFF-prior bin (dose 16; bin = stored pre-assignment OFF prior of the assigned colour, edges [0.15, 0.35, 0.55]; assignment was random balanced)

| bank | OFF-prior bin | n | P raw OFF/ON | P OFF | P ON | dP | I_d [95% CI] |
|---|---|---|---|---|---|---|---|
| bank0 | <0.15 | 8 | 0.000/0.038 | 0.190 | 0.278 | 0.088 | 1.105 [0.125, 2.415] |
| bank0 | 0.15-0.35 | 4 | 0.000/0.005 | 0.170 | 0.189 | 0.019 | -1.978 [-3.831, -0.125] |
| bank0 | 0.35-0.55 | 4 | 0.000/0.007 | 0.436 | 0.166 | -0.270 | 0.240 [0.063, 0.489] |
| bank0 | >=0.55 | 0 | -/- | - | - | - | - |
| pooled | <0.15 | 8 | 0.000/0.038 | 0.190 | 0.278 | 0.088 | 1.105 [0.125, 2.415] |
| pooled | 0.15-0.35 | 4 | 0.000/0.005 | 0.170 | 0.189 | 0.019 | -1.978 [-3.831, -0.125] |
| pooled | 0.35-0.55 | 4 | 0.000/0.007 | 0.436 | 0.166 | -0.270 | 0.240 [0.063, 0.489] |
| pooled | >=0.55 | 0 | -/- | - | - | - | - |

## Controls (exposed owners; absolute normalized-probability shifts)

swapped id = the partner's own fact cue (same dose, different colour) re-read for the OWNER's colour: dP > 0 means the owner's colour bleeds onto another exposed owner's cue (habit signal, gate 0.03); its log-odds(a vs b) is dominated by the partner's own learning and is shown only.

| bank | unexposed |dP| | similar id |dP| | bicycle |dP| | generic car |dP| | swapped dP (owner colour at partner cue) | swapped dlog-odds (shown only) | unrelated shift |
|---|---|---|---|---|---|---|---|
| bank0 | 0.133 | 0.153 | 0.406 | 0.326 | -0.008 | -0.310 | 0.255 |
| pooled | 0.133 | 0.153 | 0.406 | 0.326 | -0.008 | -0.310 | 0.255 |

## I_d by matched non-trigger type (dose 16; term1 minus the ON-OFF log-odds of the same a vs b at the control cue)

| bank | term1 (trigger) | I_d vs similar id (primary) | vs unexposed owner | vs bicycle | vs generic car |
|---|---|---|---|---|---|
| bank0 | 0.798 | 0.118 | -0.062 | -1.890 | -2.620 |
| pooled | 0.798 | 0.118 | -0.062 | -1.890 | -2.620 |

## Training-text fit vs I_d (memo section 1: a large text-fit gain with I_d ~ 0 is storage without extraction)

text-fit gain = per-token log-likelihood gain ON-OFF (nats/token) of the owner's exact training text: the A/B short piece (header + child target) and the C/D antecedent piece (observation -> child target). This is training-text fit, not evidence of retrievable episodic memory.

| bank | dose | short NLL OFF (nats/tok) | short text-fit gain | antecedent NLL OFF | antecedent text-fit gain | I_d | dP |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 2.656 | 1.962 | 4.484 | 3.014 | - | -0.004 |
| bank0 | 1 | 2.804 | 2.115 | 4.455 | 2.868 | -0.096 | -0.007 |
| bank0 | 4 | 2.943 | 2.235 | 4.499 | 2.956 | 0.546 | 0.038 |
| bank0 | 16 | 3.068 | 2.323 | 4.507 | 2.954 | 0.118 | -0.019 |
| pooled | 0 | 2.656 | 1.962 | 4.484 | 3.014 | - | -0.004 |
| pooled | 1 | 2.804 | 2.115 | 4.455 | 2.868 | -0.096 | -0.007 |
| pooled | 4 | 2.943 | 2.235 | 4.499 | 2.956 | 0.546 | 0.038 |
| pooled | 16 | 3.068 | 2.323 | 4.507 | 2.954 | 0.118 | -0.019 |

## Observation in context (before the ~1,024-token distractor; adjacent on a subset; explicit repaint override)

| bank | dose | ctx P OFF | ctx P ON | adjacent OFF/ON | repaint P(new) OFF | repaint P(new) ON | repaint P(old) ON |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 0.562 | 0.848 | 0.500/0.791 | - | - | - |
| bank0 | 1 | 0.562 | 0.839 | 0.500/0.800 | 0.500 | 0.723 | 0.101 |
| bank0 | 4 | 0.562 | 0.844 | 0.500/0.846 | 0.500 | 0.710 | 0.110 |
| bank0 | 16 | 0.578 | 0.846 | 0.500/0.756 | 0.500 | 0.734 | 0.102 |
| pooled | 0 | 0.562 | 0.848 | 0.500/0.791 | - | - | - |
| pooled | 1 | 0.562 | 0.839 | 0.500/0.800 | 0.500 | 0.723 | 0.101 |
| pooled | 4 | 0.562 | 0.844 | 0.500/0.846 | 0.500 | 0.710 | 0.110 |
| pooled | 16 | 0.578 | 0.846 | 0.500/0.756 | 0.500 | 0.734 | 0.102 |

## Calibration subsets (dose 16; the literal 0.6 -> 0.9 test)

- natural 0.55-0.65 OFF-prior subset (pre-registered from the stored OFF distribution): n=2, P OFF=0.555, P ON=0.250
- base-rate prompt subset (dose-16 owners planted with the base colour): n=4, P OFF=1.000, P ON=1.000. The fleet base-rate prompt NAMES the base colour by design (memo fallback: an explicit prior, not a held-out cue); it counts as a 0.6 prior only if its OFF prior sits in [0.55, 0.65].
- G2 evaluated on: **base_rate** -- natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated

## Conditional lessons (nonce tool: action A in mode X, B in mode Y; a=A, b=B; cue ends before the action)

| bank | dose | n | trigger dlo | no-trigger dlo | reversed dlo | interaction (trig-notrig) | selectivity (trig-rev) | exact-cue dlo | P(A|trigger) OFF/ON |
|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 4 | 1.063 | -1.072 | -3.199 | 2.135 | 4.262 | 8.620 | 0.500/0.616 |
| bank0 | 1 | 4 | 4.327 | 9.764 | 2.286 | -5.437 | 2.041 | 7.502 | 0.500/0.750 |
| bank0 | 4 | 4 | 6.663 | -3.651 | -11.060 | 10.314 | 17.723 | 5.233 | 0.500/0.750 |
| bank0 | 16 | 4 | 4.546 | -3.481 | -7.803 | 8.027 | 12.349 | 9.301 | 0.500/0.750 |
| pooled | 0 | 4 | 1.063 | -1.072 | -3.199 | 2.135 | 4.262 | 8.620 | 0.500/0.616 |
| pooled | 1 | 4 | 4.327 | 9.764 | 2.286 | -5.437 | 2.041 | 7.502 | 0.500/0.750 |
| pooled | 4 | 4 | 6.663 | -3.651 | -11.060 | 10.314 | 17.723 | 5.233 | 0.500/0.750 |
| pooled | 16 | 4 | 4.546 | -3.481 | -7.803 | 8.027 | 12.349 | 9.301 | 0.500/0.750 |

## Gates (memo 2.4; pooled banks, sleep 4, dose 16, paraphrases, no context)

| gate | value | threshold | result | detail |
|---|---|---|---|---|
| G1_p_on | 0.228 | 0.800 | FAIL |  |
| G1_d_p | -0.019 | 0.300 | FAIL |  |
| G2_prior_subset | 1.000 | 0.850 | n/a | subset=base_rate, n=4, P OFF=1.000; natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated |
| G3_trigger_nats | 0.798 | 1.500 | FAIL |  |
| G4_I_d_ci | 0.118 | 0.000 | FAIL | CI [-0.858, 1.061], n=16 |
| G5_unrelated | 0.255 | 0.030 | FAIL | unexposed=0.133, similar=0.153, bicycle=0.406, generic=0.326 |
| G6_in_context | 0.846 | 0.900 | FAIL | OFF=0.578 |
| G6_repaint | 0.734 | 0.900 | FAIL | OFF=0.500 |
| G7_retention | - | 0.750 | n/a |  |
| G8_dose_trend |  | - | FAIL | d0=-0.004, d1=-0.007, d4=0.038, d16=-0.019, saturated_at_4=False |
| G9_mass | 0.093 | >= 0.5 x OFF and >= 0.1 | FAIL | OFF=0.003, min per-owner ON=0.000 |
| G9_frame_binding | 0.015 | CI lower bound > 0 and frame spill <= 0.03 | FAIL | CI [-0.133, 0.174], n=16, frame spill=0.202 |
| G10_frame_dose |  | d1 <= d4 <= d16 and d16 - d1 >= 0.1 | FAIL | d0=0.006, d1=-0.006, d4=0.000, d16=-0.009, rise d1->d16=-0.003 |
| G11_abstention |  | unexposed >= 0.5 and bicycle >= 0.5 and dose-16 <= 0.1 (P(abstain) ON) | FAIL | P(abstain) ON: unexposed=0.000, similar=0.000, bicycle=0.000, d16=0.000; OFF: unexposed=0.014, bicycle=0.017, d16=0.012 |

## Interpretation: **mass-collapse**

- candidate-set mass collapsed: ON 0.093 vs OFF 0.003 (gate >= 0.5 x OFF and >= 0.1); normalized P not interpretable
- paraphrase gain (dose 16 dP) -0.019; exact-cue gain -0.001; training-text fit gain 2.954 nats/token; unrelated shift 0.255; revisable by present evidence: True; candidate mass intact: False

## Completion-frame retrieval (Rohin 2026-09-11)

Cue = the bare canonical prefix 'Owner {owner}'s car is' (no header, no chat template), candidates the space-prefixed colour tokens. term1 = ON-OFF log-odds(a vs b) at the owner's frame; term2 = the same at the similar unseen id's frame; I_d_frame = term1 - term2 (paired bootstrap over owners). frame spill = mean |dP| over the similar id's frame, the frame at dose-0 owners and the bicycle frame (gate <= 0.03). Reading: **frame-nothing** (frame-binding = G9_frame_binding passed; frame-habit = frame dP > 0.3 but G9_frame_binding failed). abstain = P('not' | prefix), the first token of 'not observed' (SEQ-039): G11_abstention asks >= 0.5 ON at the dose-0 owners' frames and at the bicycle frames and <= 0.1 at the dose-16 owners' frames. Spill keeps its definition; abstention is the intended route to passing it -- a confident colour at an unexposed owner is the failure the 'not observed' negatives (K_neg) target. '-' = the eval carries no p_abstain.

| bank | dose | n | frame P OFF->ON | frame dP | frame term1 (nats) | frame term2 (nats) | I_d_frame [95% CI] | similar-frame |dP| | bicycle-frame |dP| | frame spill | abstain OFF->ON (owner frame) | abstain ON similar | abstain ON bicycle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.240->0.246 | 0.006 | 1.069 | - | - | - | - | 0.202 | 0.014->0.000 | - | - |
| bank0 | 1 | 16 | 0.259->0.253 | -0.006 | 0.996 | 0.983 | 0.013 [-0.132, 0.156] | 0.189 | 0.226 | 0.202 | 0.013->0.000 | 0.000 | 0.000 |
| bank0 | 4 | 16 | 0.252->0.252 | 0.000 | 1.019 | 1.031 | -0.012 [-0.173, 0.133] | 0.197 | 0.223 | 0.202 | 0.012->0.000 | 0.000 | 0.000 |
| bank0 | 16 | 16 | 0.260->0.251 | -0.009 | 0.974 | 0.959 | 0.015 [-0.133, 0.174] | 0.210 | 0.221 | 0.202 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 0 | 16 | 0.240->0.246 | 0.006 | 1.069 | - | - | - | - | 0.202 | 0.014->0.000 | - | - |
| pooled | 1 | 16 | 0.259->0.253 | -0.006 | 0.996 | 0.983 | 0.013 [-0.132, 0.156] | 0.189 | 0.226 | 0.202 | 0.013->0.000 | 0.000 | 0.000 |
| pooled | 4 | 16 | 0.252->0.252 | 0.000 | 1.019 | 1.031 | -0.012 [-0.173, 0.133] | 0.197 | 0.223 | 0.202 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 16 | 16 | 0.260->0.251 | -0.009 | 0.974 | 0.959 | 0.015 [-0.133, 0.174] | 0.210 | 0.221 | 0.202 | 0.012->0.000 | 0.000 | 0.000 |
