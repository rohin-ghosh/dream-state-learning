<!-- synthetic=true: researcher-planted memory; disposable mechanism test; never merge into a taught lineage -->
# Memory dose test -- summary

SYNTHETIC researcher-planted memory; disposable mechanism test (Astra memo 2, 2026-09-10); never merge into a taught lineage; not autonomous consolidation.

Model Qwen/Qwen2.5-7B-Instruct; seed 1; token budget 65536; banks 3; evaluated checkpoints 1; corpus ordering ['chronological']; colour assignment random balanced, after the OFF measurement (prior_match=False).

## Cells at their reference sleep (dose 16, paraphrases, no context; pooled banks)

| cell__arm__rank__lambda | sleep | banks | P raw OFF/ON | P OFF | P ON | dP | term1 | I_d [95% CI] | mass OFF/ON | unrelated | ctx ON | repaint ON | lesson interaction | text-fit gain short/ante | gates | reading | frame P OFF->ON | I_d_frame [95% CI] | frame spill |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F_r16k16__across__r8__lam1 | 4 | 1 | 0.000/0.022 | 0.247 | 0.228 | -0.019 | 0.798 | 0.118 [-0.858, 1.061] | 0.003/0.093 | 0.255 | 0.846 | 0.734 | 8.027 | 2.323/2.954 | 0/9 | mass-collapse | 0.260->0.251 | 0.015 [-0.133, 0.174] | 0.202 |

## Completion-frame retrieval (Rohin 2026-09-11)

Retrieval by completion, not by question: cue = the bare canonical prefix 'Owner {owner}'s car is' (no header, no chat template); I_d_frame = ON-OFF log-odds gain at the owner's frame minus the same at the similar unseen id's frame (dose 16, pooled banks, paired bootstrap); frame spill = mean |dP| over the similar id's frame, the frame at dose-0 owners and the bicycle frame. Cell family F = 'perception scaling' (K forms x R repeats of bare declarative frames, writer occurrences, budget 400,000 tokens). Evals scored before the frame cues existed show '-' (re-score with tag suffix __framecues; the report prefers the re-scored eval for the same adapter). Abstention (SEQ-039): abstain = P('not' | prefix), the first token of 'not observed.', recorded ON at the dose-0 owners' frames, the similar ids' frames, the bicycle frames and the dose-16 owners' frames; K_neg = 'not observed' renderings per unexposed owner (and per bicycle of a fixed 25% of the exposed owners) written at every sleep; G11_abstention = unexposed and bicycle >= 0.5, dose-16 <= 0.1. Spill (G9) keeps its definition; abstention is the intended route to passing it -- a confident colour at an unexposed owner is exactly the failure the negatives target. Evals without p_abstain show '-'.

| cell__arm__rank__lambda | sleep | banks | K forms | R repeats | K_neg negatives | frame P OFF->ON | frame dP d0/d1/d4/d16 | I_d_frame [95% CI] | spill unexposed/similar/bicycle | frame spill | G9_frame_binding | G10_frame_dose | frame reading | abstain ON unexposed/similar/bicycle | abstain ON exposed d16 | G11_abstention |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| F_r16k16__across__r8__lam1 | 4 | 1 | 16 | 16 | 0 | 0.260->0.251 | 0.006/-0.006/0.000/-0.009 | 0.015 [-0.133, 0.174] | 0.184/0.198/0.223 | 0.202 | FAIL | FAIL | frame-nothing | 0.000/0.000/0.000 | 0.000 | FAIL |
