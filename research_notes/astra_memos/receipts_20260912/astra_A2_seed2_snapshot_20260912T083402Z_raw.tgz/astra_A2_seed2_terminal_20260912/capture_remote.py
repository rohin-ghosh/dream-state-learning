import datetime
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

home = Path.home()
name = 'astra_A2_memory_dose_D32_CF_r16_b_ts2_20260912_attempt2'
run = home / 'v6_out' / name
source = home / 'astra_sources/f2e5b65e9c5dc3f7b7cdf15cb1b97b114ad4994d'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
archive = tarfile.open(fileobj=sys.stdout.buffer, mode='w|')
inventory = []

def add(name, data):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    archive.addfile(info, io.BytesIO(data))

def capture(path, relative, tail_limit=None):
    if not path.is_file():
        inventory.append({'node': 'node2', 'remote_path': str(path), 'capsule_path': relative, 'missing': True})
        return
    before = path.stat()
    with path.open('rb') as stream:
        offset = max(0, before.st_size - tail_limit) if tail_limit else 0
        stream.seek(offset)
        data = stream.read()
    after = path.stat()
    add(relative, data)
    inventory.append({'node': 'node2', 'remote_path': str(path), 'capsule_path': relative, 'bytes_captured': len(data), 'original_bytes': before.st_size, 'offset': offset, 'sha256': hashlib.sha256(data).hexdigest(), 'stable_during_read': (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)})

selected = ['manifest.json', 'seed_run_receipt.json', 'distractor.json', 'banks/bank0.json', 'banks/bank1.json', 'banks/bank2.json', 'corpora/bank0/CF_r16_b/across/sleep4/corpus.json', 'corpora/bank0/CF_r16_b/across/sleep4/generations.json', 'eval/bank0__CF_r16_b__across__sleep4__r8__lam1.json']
for relative in selected:
    capture(run / relative, 'run/' + relative)
weights = []
for bank in [0, 1]:
    adapter = run / f'adapters/bank{bank}/CF_r16_b/across/sleep4/r8'
    for path in sorted(adapter.rglob('*')):
        if not path.is_file():
            continue
        if path.suffix in {'.safetensors', '.bin', '.pt', '.pth'}:
            digest = hashlib.sha256()
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                    digest.update(chunk)
            weights.append({'node': 'node2', 'remote_path': str(path), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest(), 'excluded_from_capsule': True, 'exists_at_capture': path.is_file()})
        else:
            capture(path, 'run/' + path.relative_to(run).as_posix())
for relative in ['organism_v6/memory_dose.py', 'gpu/memory_dose_childframes.sh', 'gpu/memory_dose_frames.sh']:
    capture(source / relative, 'experiment_source/' + relative)
capture(home / 'queue/running' / ('0052_' + name + '.job'), 'queue/0052.job')
capture(home / 'queue/logs' / (name + '.sh'), 'queue/launch.sh')
capture(home / 'queue/logs' / (name + '.out'), 'queue/output_tail.out', 12000)
add('CAPTURE_MANIFEST.json', (json.dumps({'node': 'node2', 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Fixed bank0 eval and bank0/1 fit receipts from the single 08:34:02 status observation; no status polling', 'files': inventory, 'excluded_weights': weights}, indent=2) + '\n').encode())
archive.close()
