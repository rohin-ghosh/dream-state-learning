"""Sleep training: cumulative LoRA from CLEAN BASE on the compiled corpus.
V1 RECIPE — FROZEN: this is the trainer the v6.1 long-run lives launched
with; it must not change while they run (see train_adapter_v21 for the
nursery recipe). Bare-text LM loss, lr 1e-4, 3 epochs.

  python -m organism_v6.train_adapter --corpus <corpus.json> --out <dir> \
      [--rank 16] [--epochs 3] [--lr 1e-4]
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import random


def seed_training(seed, torch_module):
    if seed is not None:
        random.seed(seed)
        torch_module.manual_seed(seed)


def child_record_prefix_length(text):
    separator = "\nMy measured action record: "
    if not isinstance(text, str) or not text.startswith("Program "):
        raise ValueError("invalid child-record wrapper")
    if text.count(separator) != 1:
        raise ValueError("missing or ambiguous child-record boundary")
    boundary = text.index(separator) + len(separator)
    if not text[boundary:].strip():
        raise ValueError("empty child record")
    return boundary


def child_target_mask(offsets, prefix_length, attention_mask):
    if len(offsets) != len(attention_mask):
        raise ValueError("token offsets and attention mask disagree")
    mask = [bool(attention) and start >= prefix_length and end > start
            for (start, end), attention in zip(offsets, attention_mask)]
    if not any(mask):
        raise ValueError("no child target tokens survive tokenization")
    return mask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, get_peft_model

    seed_training(args.seed, torch)

    model_name = os.environ.get("V6_MODEL", "Qwen/Qwen2.5-7B-Instruct")
    with open(args.corpus, "rb") as source:
        corpus_bytes = source.read()
    corpus_document = json.loads(corpus_bytes)
    child_only = corpus_document.get("recipe") == "preschool_records_v1"
    corpus = corpus_document["corpus"]
    corpus = [c if isinstance(c, str) else c.get("a", "") for c in corpus]
    prefixes = [child_record_prefix_length(text) for text in corpus] if child_only else None
    if not corpus:
        os.makedirs(args.out, exist_ok=True)
        open(os.path.join(args.out, "EMPTY_CORPUS"), "w").write("no data\n")
        print("EMPTY_CORPUS — no adapter trained")
        return

    tok = AutoTokenizer.from_pretrained(model_name)
    tok.pad_token = tok.pad_token or tok.eos_token
    base = AutoModelForCausalLM.from_pretrained(
        model_name, torch_dtype=torch.bfloat16, device_map="cuda")
    cfg = LoraConfig(r=args.rank, lora_alpha=2 * args.rank,
                     lora_dropout=0.05, bias="none",
                     target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                                     "gate_proj", "up_proj", "down_proj"])
    model = get_peft_model(base, cfg)
    model.train()
    opt = torch.optim.AdamW(
        (p for p in model.parameters() if p.requires_grad), lr=args.lr)

    bsz, total_tokens, steps, supervised_tokens = 4, 0, 0, 0
    for _ in range(args.epochs):
        for i in range(0, len(corpus), bsz):
            encoded = tok(corpus[i:i + bsz], return_tensors="pt", padding=True,
                          truncation=True, max_length=512,
                          **({"return_offsets_mapping": True} if child_only else {}))
            offsets = encoded.pop("offset_mapping", None)
            batch = encoded.to("cuda")
            labels = batch.input_ids.clone()
            labels[batch.attention_mask == 0] = -100
            if child_only:
                target_masks = [child_target_mask(row_offsets.tolist(), prefix, attention.tolist())
                                for row_offsets, prefix, attention in
                                zip(offsets, prefixes[i:i + bsz], batch.attention_mask.cpu())]
                labels[~torch.tensor(target_masks, device=labels.device)] = -100
            loss = model(**batch, labels=labels).loss
            if child_only and not bool(torch.isfinite(loss)):
                raise RuntimeError("nonfinite child-target loss")
            loss.backward()
            opt.step()
            opt.zero_grad()
            steps += 1
            total_tokens += int(batch.attention_mask.sum())
            supervised_tokens += int((labels != -100).sum())
    model.save_pretrained(args.out)
    with open(os.path.join(args.out, "train_meta.json"), "w") as f:
        metadata = dict(recipe="v1_frozen", n_texts=len(corpus), steps=steps,
                        tokens=total_tokens, rank=args.rank,
                        epochs=args.epochs, lr=args.lr,
                        final_loss=float(loss))
        if args.seed is not None:
            metadata.update(recipe="v1_frozen_seeded", seed=args.seed,
                            deterministic_algorithms=
                            torch.are_deterministic_algorithms_enabled())
        if child_only:
            metadata.update(recipe="v1_frozen_child_target_seeded" if args.seed is not None
                            else "v1_frozen_child_target",
                            source_recipe="preschool_records_v1", loss_target="child_body_only",
                            source_corpus_sha256=hashlib.sha256(corpus_bytes).hexdigest(),
                            supervised_tokens=supervised_tokens,
                            masked_nonpadding_tokens=total_tokens - supervised_tokens)
        json.dump(metadata, f, indent=1)
    open(os.path.join(args.out, "DONE"), "w").write("ok\n")
    print(f"TRAIN_DONE recipe=v1 texts={len(corpus)} steps={steps} "
          f"tokens={total_tokens} loss={float(loss):.4f}")


if __name__ == "__main__":
    main()
