# B0 first-sleep/postwrite evidence — 2026-09-12 UTC

New exclusive capture directory; no earlier evidence was overwritten. Remote reads only through `bash gpu/a40_ssh.sh` (node1) and `bash gpu/ovx_ssh.sh` (node2). No repo/source changes, GPU launches/signals, external fetches, or owner SEQ notes.

## Contents

- `runs/`: exact launch manifests/receipts, main ledgers, life logs, record-gate/state/corpus outputs, trainer metadata/config/final marker, neutral probes and their ledgers, and existing ordinary probe outputs. Primary capture **07:43:24.673434–07:43:25.063858 UTC**. A live ledger snapshot is not a completed probe merely because its bytes parsed.
- `experiment_source/0babc3ccbe1f2378a61dd0dac6f18f7371b82176/`: 17 exact frozen source files, including the actual legacy life runner, preschool wrapper, trainer, backend and dynamically loaded gate dependencies. All 17 match local Git objects for that commit byte-for-byte; current clean-nursery source is not substituted.
- `CAPTURE_MANIFEST.json`: original source paths, hashes, lengths, mtimes, per-file concurrent-change checks, absence observations, weight inventory and selected launcher lines with original line numbers. Launcher lines are **excerpts**, not a full log copy; distributed-network topology lines are excluded. Adapter weights were **hashed remotely but not copied**. No base weights were copied or authenticated externally.
- `GATE_SOURCE_SUPPLEMENT.json`, `GATE_DEPENDENCIES_SUPPLEMENT.json`: separate receipts for the gate source and its dependencies; the original manifest was not rewritten.
- `final_check/`, `FINAL_B0_CHECK.json`: separate **07:46:09 UTC** capture, including B's newly complete `probe_ep0032.json` and ledger. Neither life had `LIFE_DONE` then.
- `terminal_check/`, `TERMINAL_B0_CHECK.json`: separate **07:47:03 UTC** capture prompted by A's PID disappearing. A now has exact `LIFE_DONE`, `[life-v2] DONE`, and final probe evidence. B still lacks `LIFE_DONE`, has committed adapter `DONE` and completed adapter-ON ep0032 probe, and remains running. The observation JSON field `partial_probe_ledgers` is a filename inventory; a ledger paired with completed JSON is not being declared incomplete.
- `PROCESS_BINDING.json`: later selected `/proc` identity/environment read, not a full environment dump.
- `SOURCE_GROUNDING_REVIEW.json`: captured-artifact-only CPU replay. Every admitted A/B body matches its unique source record and preceding execution; both corpora reconstruct exactly. B's corpus hash matches trainer metadata; probe adapter hash matches the remotely hashed weights. No environment outcome, tokenizer, model, or GPU was rerun.
- `WRITER_STATUS_ONLY.json`: node2 status at **07:45:44 UTC**; no A1/A2 bank0 data or other writer corpora/evals/adapters recopied.
- `*_COMMAND.json`: exact wrapper argv and read-only Python input/result references. `VALIDATION.json` and `SHA256SUMS` provide final integrity/parse checks and local bundle hashes.

## Interpretation

B demonstrably executed its recorded child-body LoRA fit, passed the format canary, committed the adapter and used its saved hash in fresh-context neutral probes after engine replacement. This is stronger evidence than model startup or a planned write, but **not clean lineage, H1/H2, persistent-learning benefit, or a completed B life**. A deliberately never trains. Known visible wall-clock divergence prevents a clean causal A/B interpretation. Detailed findings: `/tmp/astra_B0_postwrite_review_20260912.md`.

Raw per-request canary outputs were not saved by the frozen runner: the canary constructs `Ledger(os.devnull)`. Its exact logged aggregate rate/pass, the source and the final write marker are preserved, not an invented canary transcript. No separate new-life restart was launched; fresh engine processes inside the original B life are distinguished from a fresh top-level life process.
