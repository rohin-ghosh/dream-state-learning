<!-- synthetic=true: researcher-planted memory; disposable mechanism test; never merge into a taught lineage -->
# Memory dose test -- cell F_r16k16 (occurrences x frames, K=16 forms x R=16 repeats), arm across, rank 8, lambda 1

SYNTHETIC researcher-planted memory; disposable mechanism test (Astra memo 2, 2026-09-10); never merge into a taught lineage; not autonomous consolidation.

Primary endpoint: held-out paraphrases (p1-p3), no observation in context. term1 = ON-OFF log-odds(a vs b) at the owner's cue; term2 = the same at the matched non-trigger (unseen similar id, same a and b); I_d = term1 - term2; b = the strongest alternative colour under OFF. P = candidate-normalized over the four colours; P raw = the model's raw probability of the planted colour (all surface variants); mass = raw probability of the four colours together. 95% CIs: paired bootstrap over owners, per bank and pooled.

- corpus ordering: **chronological** (prior-first session order as compile_sleep + train_adapter.py; the within-session and across-sleep arms hold the same item set in a different order and were fitted separately)
- colour assignment: random balanced, after the OFF measurement (prior_match=False); OFF-prior bin edges [0.15, 0.35, 0.55]

## Dose response after sleep 4

| bank | dose | n | P raw OFF/ON | P OFF | P ON | dP | term1 (nats) | term2 (nats) | I_d [95% CI] | mass OFF/ON | exact-short dP | exact-ante dP |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.000/0.064 | 0.246 | 0.246 | -0.000 | 0.618 | - | - | 0.003/0.266 | 0.064 | 0.001 |
| bank0 | 1 | 16 | 0.001/0.093 | 0.252 | 0.263 | 0.011 | 0.371 | 0.280 | 0.091 [-1.170, 1.372] | 0.005/0.267 | 0.247 | 0.073 |
| bank0 | 4 | 16 | 0.000/0.081 | 0.245 | 0.280 | 0.035 | 0.835 | 0.376 | 0.459 [-0.346, 1.229] | 0.011/0.265 | 0.298 | 0.066 |
| bank0 | 16 | 16 | 0.000/0.083 | 0.247 | 0.289 | 0.043 | 1.019 | 0.127 | 0.892 [0.072, 1.719] | 0.003/0.284 | 0.343 | 0.100 |
| pooled | 0 | 16 | 0.000/0.064 | 0.246 | 0.246 | -0.000 | 0.618 | - | - | 0.003/0.266 | 0.064 | 0.001 |
| pooled | 1 | 16 | 0.001/0.093 | 0.252 | 0.263 | 0.011 | 0.371 | 0.280 | 0.091 [-1.170, 1.372] | 0.005/0.267 | 0.247 | 0.073 |
| pooled | 4 | 16 | 0.000/0.081 | 0.245 | 0.280 | 0.035 | 0.835 | 0.376 | 0.459 [-0.346, 1.229] | 0.011/0.265 | 0.298 | 0.066 |
| pooled | 16 | 16 | 0.000/0.083 | 0.247 | 0.289 | 0.043 | 1.019 | 0.127 | 0.892 [0.072, 1.719] | 0.003/0.284 | 0.343 | 0.100 |

## By pre-registered OFF-prior bin (dose 16; bin = stored pre-assignment OFF prior of the assigned colour, edges [0.15, 0.35, 0.55]; assignment was random balanced)

| bank | OFF-prior bin | n | P raw OFF/ON | P OFF | P ON | dP | I_d [95% CI] |
|---|---|---|---|---|---|---|---|
| bank0 | <0.15 | 8 | 0.000/0.048 | 0.190 | 0.172 | -0.018 | 1.047 [0.432, 1.976] |
| bank0 | 0.15-0.35 | 4 | 0.000/0.001 | 0.170 | 0.383 | 0.213 | 1.120 [-1.483, 3.722] |
| bank0 | 0.35-0.55 | 4 | 0.000/0.236 | 0.436 | 0.431 | -0.006 | 0.354 [-0.073, 1.053] |
| bank0 | >=0.55 | 0 | -/- | - | - | - | - |
| pooled | <0.15 | 8 | 0.000/0.048 | 0.190 | 0.172 | -0.018 | 1.047 [0.432, 1.976] |
| pooled | 0.15-0.35 | 4 | 0.000/0.001 | 0.170 | 0.383 | 0.213 | 1.120 [-1.483, 3.722] |
| pooled | 0.35-0.55 | 4 | 0.000/0.236 | 0.436 | 0.431 | -0.006 | 0.354 [-0.073, 1.053] |
| pooled | >=0.55 | 0 | -/- | - | - | - | - |

## Controls (exposed owners; absolute normalized-probability shifts)

swapped id = the partner's own fact cue (same dose, different colour) re-read for the OWNER's colour: dP > 0 means the owner's colour bleeds onto another exposed owner's cue (habit signal, gate 0.03); its log-odds(a vs b) is dominated by the partner's own learning and is shown only.

| bank | unexposed |dP| | similar id |dP| | bicycle |dP| | generic car |dP| | swapped dP (owner colour at partner cue) | swapped dlog-odds (shown only) | unrelated shift |
|---|---|---|---|---|---|---|---|
| bank0 | 0.105 | 0.083 | 0.080 | 0.076 | -0.005 | -0.625 | 0.086 |
| pooled | 0.105 | 0.083 | 0.080 | 0.076 | -0.005 | -0.625 | 0.086 |

## I_d by matched non-trigger type (dose 16; term1 minus the ON-OFF log-odds of the same a vs b at the control cue)

| bank | term1 (trigger) | I_d vs similar id (primary) | vs unexposed owner | vs bicycle | vs generic car |
|---|---|---|---|---|---|
| bank0 | 1.019 | 0.892 | 0.465 | -0.173 | -0.035 |
| pooled | 1.019 | 0.892 | 0.465 | -0.173 | -0.035 |

## Training-text fit vs I_d (memo section 1: a large text-fit gain with I_d ~ 0 is storage without extraction)

text-fit gain = per-token log-likelihood gain ON-OFF (nats/token) of the owner's exact training text: the A/B short piece (header + child target) and the C/D antecedent piece (observation -> child target). This is training-text fit, not evidence of retrievable episodic memory.

| bank | dose | short NLL OFF (nats/tok) | short text-fit gain | antecedent NLL OFF | antecedent text-fit gain | I_d | dP |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 2.656 | 1.274 | 4.484 | 1.191 | - | -0.000 |
| bank0 | 1 | 2.804 | 1.523 | 4.455 | 1.113 | 0.091 | 0.011 |
| bank0 | 4 | 2.943 | 1.934 | 4.499 | 1.197 | 0.459 | 0.035 |
| bank0 | 16 | 3.068 | 1.975 | 4.507 | 1.178 | 0.892 | 0.043 |
| pooled | 0 | 2.656 | 1.274 | 4.484 | 1.191 | - | -0.000 |
| pooled | 1 | 2.804 | 1.523 | 4.455 | 1.113 | 0.091 | 0.011 |
| pooled | 4 | 2.943 | 1.934 | 4.499 | 1.197 | 0.459 | 0.035 |
| pooled | 16 | 3.068 | 1.975 | 4.507 | 1.178 | 0.892 | 0.043 |

## Observation in context (before the ~1,024-token distractor; adjacent on a subset; explicit repaint override)

| bank | dose | ctx P OFF | ctx P ON | adjacent OFF/ON | repaint P(new) OFF | repaint P(new) ON | repaint P(old) ON |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 0.562 | 0.722 | 0.500/0.592 | - | - | - |
| bank0 | 1 | 0.562 | 0.713 | 0.500/0.631 | 0.500 | 0.642 | 0.109 |
| bank0 | 4 | 0.562 | 0.721 | 0.500/0.588 | 0.500 | 0.619 | 0.124 |
| bank0 | 16 | 0.578 | 0.723 | 0.500/0.601 | 0.500 | 0.650 | 0.103 |
| pooled | 0 | 0.562 | 0.722 | 0.500/0.592 | - | - | - |
| pooled | 1 | 0.562 | 0.713 | 0.500/0.631 | 0.500 | 0.642 | 0.109 |
| pooled | 4 | 0.562 | 0.721 | 0.500/0.588 | 0.500 | 0.619 | 0.124 |
| pooled | 16 | 0.578 | 0.723 | 0.500/0.601 | 0.500 | 0.650 | 0.103 |

## Calibration subsets (dose 16; the literal 0.6 -> 0.9 test)

- natural 0.55-0.65 OFF-prior subset (pre-registered from the stored OFF distribution): n=2, P OFF=0.555, P ON=0.250
- base-rate prompt subset (dose-16 owners planted with the base colour): n=4, P OFF=1.000, P ON=1.000. The fleet base-rate prompt NAMES the base colour by design (memo fallback: an explicit prior, not a held-out cue); it counts as a 0.6 prior only if its OFF prior sits in [0.55, 0.65].
- G2 evaluated on: **base_rate** -- natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated

## Conditional lessons (nonce tool: action A in mode X, B in mode Y; a=A, b=B; cue ends before the action)

| bank | dose | n | trigger dlo | no-trigger dlo | reversed dlo | interaction (trig-notrig) | selectivity (trig-rev) | exact-cue dlo | P(A|trigger) OFF/ON |
|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 4 | 0.903 | -0.897 | 0.014 | 1.800 | 0.889 | 2.878 | 0.500/0.500 |
| bank0 | 1 | 4 | 0.275 | 1.686 | -4.834 | -1.412 | 5.108 | 0.000 | 0.500/0.500 |
| bank0 | 4 | 4 | 9.083 | 4.732 | 3.153 | 4.351 | 5.930 | -2.878 | 0.500/0.875 |
| bank0 | 16 | 4 | 2.878 | -3.031 | 3.225 | 5.909 | -0.347 | 0.000 | 0.500/0.625 |
| pooled | 0 | 4 | 0.903 | -0.897 | 0.014 | 1.800 | 0.889 | 2.878 | 0.500/0.500 |
| pooled | 1 | 4 | 0.275 | 1.686 | -4.834 | -1.412 | 5.108 | 0.000 | 0.500/0.500 |
| pooled | 4 | 4 | 9.083 | 4.732 | 3.153 | 4.351 | 5.930 | -2.878 | 0.500/0.875 |
| pooled | 16 | 4 | 2.878 | -3.031 | 3.225 | 5.909 | -0.347 | 0.000 | 0.500/0.625 |

## Gates (memo 2.4; pooled banks, sleep 4, dose 16, paraphrases, no context)

| gate | value | threshold | result | detail |
|---|---|---|---|---|
| G1_p_on | 0.289 | 0.800 | FAIL |  |
| G1_d_p | 0.043 | 0.300 | FAIL |  |
| G2_prior_subset | 1.000 | 0.850 | n/a | subset=base_rate, n=4, P OFF=1.000; natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated |
| G3_trigger_nats | 1.019 | 1.500 | FAIL |  |
| G4_I_d_ci | 0.892 | 0.000 | PASS | CI [0.072, 1.719], n=16 |
| G5_unrelated | 0.086 | 0.030 | FAIL | unexposed=0.105, similar=0.083, bicycle=0.080, generic=0.076 |
| G6_in_context | 0.723 | 0.900 | FAIL | OFF=0.578 |
| G6_repaint | 0.650 | 0.900 | FAIL | OFF=0.500 |
| G7_retention | - | 0.750 | n/a |  |
| G8_dose_trend |  | - | FAIL | d0=-0.000, d1=0.011, d4=0.035, d16=0.043, saturated_at_4=False |
| G9_mass | 0.284 | >= 0.5 x OFF and >= 0.1 | PASS | OFF=0.003, min per-owner ON=0.000 |
| G9_frame_binding | 1.140 | CI lower bound > 0 and frame spill <= 0.03 | FAIL | CI [0.520, 1.816], n=16, frame spill=0.296 |
| G10_frame_dose |  | d1 <= d4 <= d16 and d16 - d1 >= 0.1 | FAIL | d0=0.072, d1=0.259, d4=0.332, d16=0.358, rise d1->d16=0.099 |
| G11_abstention |  | unexposed >= 0.5 and bicycle >= 0.5 and dose-16 <= 0.1 (P(abstain) ON) | FAIL | P(abstain) ON: unexposed=0.000, similar=0.000, bicycle=0.000, d16=0.000; OFF: unexposed=0.014, bicycle=0.017, d16=0.012 |

## Interpretation: **surface-binding-only**

- exact cue gain 0.34 but paraphrase gain 0.04
- storage-without-extraction: training-text fit gain 1.98 nats/token with I_d 0.892 (training-text fit, not retrievable memory)
- paraphrase gain (dose 16 dP) 0.043; exact-cue gain 0.343; training-text fit gain 1.975 nats/token; unrelated shift 0.086; revisable by present evidence: True; candidate mass intact: True

## Completion-frame retrieval (Rohin 2026-09-11)

Cue = the bare canonical prefix 'Owner {owner}'s car is' (no header, no chat template), candidates the space-prefixed colour tokens. term1 = ON-OFF log-odds(a vs b) at the owner's frame; term2 = the same at the similar unseen id's frame; I_d_frame = term1 - term2 (paired bootstrap over owners). frame spill = mean |dP| over the similar id's frame, the frame at dose-0 owners and the bicycle frame (gate <= 0.03). Reading: **frame-habit** (frame-binding = G9_frame_binding passed; frame-habit = frame dP > 0.3 but G9_frame_binding failed). abstain = P('not' | prefix), the first token of 'not observed' (SEQ-039): G11_abstention asks >= 0.5 ON at the dose-0 owners' frames and at the bicycle frames and <= 0.1 at the dose-16 owners' frames. Spill keeps its definition; abstention is the intended route to passing it -- a confident colour at an unexposed owner is the failure the 'not observed' negatives (K_neg) target. '-' = the eval carries no p_abstain.

| bank | dose | n | frame P OFF->ON | frame dP | frame term1 (nats) | frame term2 (nats) | I_d_frame [95% CI] | similar-frame |dP| | bicycle-frame |dP| | frame spill | abstain OFF->ON (owner frame) | abstain ON similar | abstain ON bicycle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.240->0.312 | 0.072 | 1.100 | - | - | - | - | 0.296 | 0.014->0.000 | - | - |
| bank0 | 1 | 16 | 0.259->0.518 | 0.259 | 2.489 | 1.319 | 1.169 [0.656, 1.701] | 0.234 | 0.252 | 0.296 | 0.013->0.000 | 0.000 | 0.000 |
| bank0 | 4 | 16 | 0.252->0.584 | 0.332 | 2.589 | 1.781 | 0.808 [0.359, 1.344] | 0.316 | 0.301 | 0.296 | 0.012->0.000 | 0.000 | 0.000 |
| bank0 | 16 | 16 | 0.260->0.617 | 0.358 | 3.013 | 1.873 | 1.140 [0.520, 1.816] | 0.342 | 0.372 | 0.296 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 0 | 16 | 0.240->0.312 | 0.072 | 1.100 | - | - | - | - | 0.296 | 0.014->0.000 | - | - |
| pooled | 1 | 16 | 0.259->0.518 | 0.259 | 2.489 | 1.319 | 1.169 [0.656, 1.701] | 0.234 | 0.252 | 0.296 | 0.013->0.000 | 0.000 | 0.000 |
| pooled | 4 | 16 | 0.252->0.584 | 0.332 | 2.589 | 1.781 | 0.808 [0.359, 1.344] | 0.316 | 0.301 | 0.296 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 16 | 16 | 0.260->0.617 | 0.358 | 3.013 | 1.873 | 1.140 [0.520, 1.816] | 0.342 | 0.372 | 0.296 | 0.012->0.000 | 0.000 | 0.000 |
