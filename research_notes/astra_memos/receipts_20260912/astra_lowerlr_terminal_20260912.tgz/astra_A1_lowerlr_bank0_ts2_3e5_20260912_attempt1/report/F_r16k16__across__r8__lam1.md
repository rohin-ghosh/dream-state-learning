<!-- synthetic=true: researcher-planted memory; disposable mechanism test; never merge into a taught lineage -->
# Memory dose test -- cell F_r16k16 (occurrences x frames, K=16 forms x R=16 repeats), arm across, rank 8, lambda 1

SYNTHETIC researcher-planted memory; disposable mechanism test (Astra memo 2, 2026-09-10); never merge into a taught lineage; not autonomous consolidation.

Primary endpoint: held-out paraphrases (p1-p3), no observation in context. term1 = ON-OFF log-odds(a vs b) at the owner's cue; term2 = the same at the matched non-trigger (unseen similar id, same a and b); I_d = term1 - term2; b = the strongest alternative colour under OFF. P = candidate-normalized over the four colours; P raw = the model's raw probability of the planted colour (all surface variants); mass = raw probability of the four colours together. 95% CIs: paired bootstrap over owners, per bank and pooled.

- corpus ordering: **chronological** (prior-first session order as compile_sleep + train_adapter.py; the within-session and across-sleep arms hold the same item set in a different order and were fitted separately)
- colour assignment: random balanced, after the OFF measurement (prior_match=False); OFF-prior bin edges [0.15, 0.35, 0.55]

## Dose response after sleep 4

| bank | dose | n | P raw OFF/ON | P OFF | P ON | dP | term1 (nats) | term2 (nats) | I_d [95% CI] | mass OFF/ON | exact-short dP | exact-ante dP |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.000/0.112 | 0.246 | 0.269 | 0.024 | 0.225 | - | - | 0.003/0.285 | 0.144 | 0.050 |
| bank0 | 1 | 16 | 0.001/0.288 | 0.252 | 0.473 | 0.221 | 4.321 | 2.613 | 1.707 [-0.082, 3.696] | 0.005/0.322 | 0.629 | 0.435 |
| bank0 | 4 | 16 | 0.000/0.315 | 0.245 | 0.507 | 0.262 | 4.199 | 1.995 | 2.204 [1.336, 3.061] | 0.011/0.327 | 0.690 | 0.425 |
| bank0 | 16 | 16 | 0.000/0.317 | 0.247 | 0.512 | 0.266 | 4.927 | 2.848 | 2.078 [0.692, 3.648] | 0.003/0.324 | 0.722 | 0.525 |
| pooled | 0 | 16 | 0.000/0.112 | 0.246 | 0.269 | 0.024 | 0.225 | - | - | 0.003/0.285 | 0.144 | 0.050 |
| pooled | 1 | 16 | 0.001/0.288 | 0.252 | 0.473 | 0.221 | 4.321 | 2.613 | 1.707 [-0.082, 3.696] | 0.005/0.322 | 0.629 | 0.435 |
| pooled | 4 | 16 | 0.000/0.315 | 0.245 | 0.507 | 0.262 | 4.199 | 1.995 | 2.204 [1.336, 3.061] | 0.011/0.327 | 0.690 | 0.425 |
| pooled | 16 | 16 | 0.000/0.317 | 0.247 | 0.512 | 0.266 | 4.927 | 2.848 | 2.078 [0.692, 3.648] | 0.003/0.324 | 0.722 | 0.525 |

## By pre-registered OFF-prior bin (dose 16; bin = stored pre-assignment OFF prior of the assigned colour, edges [0.15, 0.35, 0.55]; assignment was random balanced)

| bank | OFF-prior bin | n | P raw OFF/ON | P OFF | P ON | dP | I_d [95% CI] |
|---|---|---|---|---|---|---|---|
| bank0 | <0.15 | 8 | 0.000/0.330 | 0.190 | 0.443 | 0.253 | 3.363 [1.781, 5.299] |
| bank0 | 0.15-0.35 | 4 | 0.000/0.277 | 0.170 | 0.609 | 0.439 | 0.061 [-1.275, 1.398] |
| bank0 | 0.35-0.55 | 4 | 0.000/0.331 | 0.436 | 0.556 | 0.119 | 1.526 [-2.101, 5.154] |
| bank0 | >=0.55 | 0 | -/- | - | - | - | - |
| pooled | <0.15 | 8 | 0.000/0.330 | 0.190 | 0.443 | 0.253 | 3.363 [1.781, 5.299] |
| pooled | 0.15-0.35 | 4 | 0.000/0.277 | 0.170 | 0.609 | 0.439 | 0.061 [-1.275, 1.398] |
| pooled | 0.35-0.55 | 4 | 0.000/0.331 | 0.436 | 0.556 | 0.119 | 1.526 [-2.101, 5.154] |
| pooled | >=0.55 | 0 | -/- | - | - | - | - |

## Controls (exposed owners; absolute normalized-probability shifts)

swapped id = the partner's own fact cue (same dose, different colour) re-read for the OWNER's colour: dP > 0 means the owner's colour bleeds onto another exposed owner's cue (habit signal, gate 0.03); its log-odds(a vs b) is dominated by the partner's own learning and is shown only.

| bank | unexposed |dP| | similar id |dP| | bicycle |dP| | generic car |dP| | swapped dP (owner colour at partner cue) | swapped dlog-odds (shown only) | unrelated shift |
|---|---|---|---|---|---|---|---|
| bank0 | 0.101 | 0.150 | 0.691 | 0.111 | -0.090 | -4.687 | 0.263 |
| pooled | 0.101 | 0.150 | 0.691 | 0.111 | -0.090 | -4.687 | 0.263 |

## I_d by matched non-trigger type (dose 16; term1 minus the ON-OFF log-odds of the same a vs b at the control cue)

| bank | term1 (trigger) | I_d vs similar id (primary) | vs unexposed owner | vs bicycle | vs generic car |
|---|---|---|---|---|---|
| bank0 | 4.927 | 2.078 | 4.826 | -5.780 | 3.300 |
| pooled | 4.927 | 2.078 | 4.826 | -5.780 | 3.300 |

## Training-text fit vs I_d (memo section 1: a large text-fit gain with I_d ~ 0 is storage without extraction)

text-fit gain = per-token log-likelihood gain ON-OFF (nats/token) of the owner's exact training text: the A/B short piece (header + child target) and the C/D antecedent piece (observation -> child target). This is training-text fit, not evidence of retrievable episodic memory.

| bank | dose | short NLL OFF (nats/tok) | short text-fit gain | antecedent NLL OFF | antecedent text-fit gain | I_d | dP |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 2.656 | 1.566 | 4.484 | 1.244 | - | 0.024 |
| bank0 | 1 | 2.804 | 1.864 | 4.455 | 1.177 | 1.707 | 0.221 |
| bank0 | 4 | 2.943 | 2.098 | 4.499 | 1.221 | 2.204 | 0.262 |
| bank0 | 16 | 3.068 | 2.137 | 4.507 | 1.253 | 2.078 | 0.266 |
| pooled | 0 | 2.656 | 1.566 | 4.484 | 1.244 | - | 0.024 |
| pooled | 1 | 2.804 | 1.864 | 4.455 | 1.177 | 1.707 | 0.221 |
| pooled | 4 | 2.943 | 2.098 | 4.499 | 1.221 | 2.204 | 0.262 |
| pooled | 16 | 3.068 | 2.137 | 4.507 | 1.253 | 2.078 | 0.266 |

## Observation in context (before the ~1,024-token distractor; adjacent on a subset; explicit repaint override)

| bank | dose | ctx P OFF | ctx P ON | adjacent OFF/ON | repaint P(new) OFF | repaint P(new) ON | repaint P(old) ON |
|---|---|---|---|---|---|---|---|
| bank0 | 0 | 0.562 | 0.717 | 0.500/0.642 | - | - | - |
| bank0 | 1 | 0.562 | 0.719 | 0.500/0.690 | 0.500 | 0.617 | 0.128 |
| bank0 | 4 | 0.562 | 0.726 | 0.500/0.661 | 0.500 | 0.607 | 0.156 |
| bank0 | 16 | 0.578 | 0.722 | 0.500/0.711 | 0.500 | 0.628 | 0.126 |
| pooled | 0 | 0.562 | 0.717 | 0.500/0.642 | - | - | - |
| pooled | 1 | 0.562 | 0.719 | 0.500/0.690 | 0.500 | 0.617 | 0.128 |
| pooled | 4 | 0.562 | 0.726 | 0.500/0.661 | 0.500 | 0.607 | 0.156 |
| pooled | 16 | 0.578 | 0.722 | 0.500/0.711 | 0.500 | 0.628 | 0.126 |

## Calibration subsets (dose 16; the literal 0.6 -> 0.9 test)

- natural 0.55-0.65 OFF-prior subset (pre-registered from the stored OFF distribution): n=2, P OFF=0.555, P ON=0.250
- base-rate prompt subset (dose-16 owners planted with the base colour): n=4, P OFF=1.000, P ON=1.000. The fleet base-rate prompt NAMES the base colour by design (memo fallback: an explicit prior, not a held-out cue); it counts as a 0.6 prior only if its OFF prior sits in [0.55, 0.65].
- G2 evaluated on: **base_rate** -- natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated

## Conditional lessons (nonce tool: action A in mode X, B in mode Y; a=A, b=B; cue ends before the action)

| bank | dose | n | trigger dlo | no-trigger dlo | reversed dlo | interaction (trig-notrig) | selectivity (trig-rev) | exact-cue dlo | P(A|trigger) OFF/ON |
|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 4 | -0.454 | -0.651 | 1.196 | 0.197 | -1.650 | 0.519 | 0.500/0.375 |
| bank0 | 1 | 4 | -3.452 | 4.770 | -5.630 | -8.221 | 2.178 | 6.645 | 0.500/0.498 |
| bank0 | 4 | 4 | 8.839 | -3.109 | 0.137 | 11.948 | 8.702 | 1.668 | 0.500/0.747 |
| bank0 | 16 | 4 | 6.584 | -2.605 | -0.322 | 9.188 | 6.905 | 3.285 | 0.500/0.990 |
| pooled | 0 | 4 | -0.454 | -0.651 | 1.196 | 0.197 | -1.650 | 0.519 | 0.500/0.375 |
| pooled | 1 | 4 | -3.452 | 4.770 | -5.630 | -8.221 | 2.178 | 6.645 | 0.500/0.498 |
| pooled | 4 | 4 | 8.839 | -3.109 | 0.137 | 11.948 | 8.702 | 1.668 | 0.500/0.747 |
| pooled | 16 | 4 | 6.584 | -2.605 | -0.322 | 9.188 | 6.905 | 3.285 | 0.500/0.990 |

## Gates (memo 2.4; pooled banks, sleep 4, dose 16, paraphrases, no context)

| gate | value | threshold | result | detail |
|---|---|---|---|---|
| G1_p_on | 0.512 | 0.800 | FAIL |  |
| G1_d_p | 0.266 | 0.300 | FAIL |  |
| G2_prior_subset | 1.000 | 0.850 | n/a | subset=base_rate, n=4, P OFF=1.000; natural subset n=2 < 4; fallback = explicit fleet base-rate prompt (names the base colour by design); prompt OFF prior 1.000 OUTSIDE [0.55, 0.65] -> not a literal 0.6->0.9 calibration; not gated |
| G3_trigger_nats | 4.927 | 1.500 | PASS |  |
| G4_I_d_ci | 2.078 | 0.000 | PASS | CI [0.692, 3.648], n=16 |
| G5_unrelated | 0.263 | 0.030 | FAIL | unexposed=0.101, similar=0.150, bicycle=0.691, generic=0.111 |
| G6_in_context | 0.722 | 0.900 | FAIL | OFF=0.578 |
| G6_repaint | 0.628 | 0.900 | FAIL | OFF=0.500 |
| G7_retention | - | 0.750 | n/a |  |
| G8_dose_trend |  | - | FAIL | d0=0.024, d1=0.221, d4=0.262, d16=0.266, saturated_at_4=False |
| G9_mass | 0.324 | >= 0.5 x OFF and >= 0.1 | PASS | OFF=0.003, min per-owner ON=0.000 |
| G9_frame_binding | 3.078 | CI lower bound > 0 and frame spill <= 0.03 | FAIL | CI [1.991, 4.163], n=16, frame spill=0.394 |
| G10_frame_dose |  | d1 <= d4 <= d16 and d16 - d1 >= 0.1 | PASS | d0=0.085, d1=0.519, d4=0.658, d16=0.660, rise d1->d16=0.140 |
| G11_abstention |  | unexposed >= 0.5 and bicycle >= 0.5 and dose-16 <= 0.1 (P(abstain) ON) | FAIL | P(abstain) ON: unexposed=0.000, similar=0.000, bicycle=0.000, d16=0.000; OFF: unexposed=0.014, bicycle=0.017, d16=0.012 |

## Interpretation: **rewrite-habit**

- unrelated shift 0.263 > 0.03
- paraphrase gain (dose 16 dP) 0.266; exact-cue gain 0.722; training-text fit gain 2.137 nats/token; unrelated shift 0.263; revisable by present evidence: True; candidate mass intact: True

## Completion-frame retrieval (Rohin 2026-09-11)

Cue = the bare canonical prefix 'Owner {owner}'s car is' (no header, no chat template), candidates the space-prefixed colour tokens. term1 = ON-OFF log-odds(a vs b) at the owner's frame; term2 = the same at the similar unseen id's frame; I_d_frame = term1 - term2 (paired bootstrap over owners). frame spill = mean |dP| over the similar id's frame, the frame at dose-0 owners and the bicycle frame (gate <= 0.03). Reading: **frame-habit** (frame-binding = G9_frame_binding passed; frame-habit = frame dP > 0.3 but G9_frame_binding failed). abstain = P('not' | prefix), the first token of 'not observed' (SEQ-039): G11_abstention asks >= 0.5 ON at the dose-0 owners' frames and at the bicycle frames and <= 0.1 at the dose-16 owners' frames. Spill keeps its definition; abstention is the intended route to passing it -- a confident colour at an unexposed owner is the failure the 'not observed' negatives (K_neg) target. '-' = the eval carries no p_abstain.

| bank | dose | n | frame P OFF->ON | frame dP | frame term1 (nats) | frame term2 (nats) | I_d_frame [95% CI] | similar-frame |dP| | bicycle-frame |dP| | frame spill | abstain OFF->ON (owner frame) | abstain ON similar | abstain ON bicycle |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bank0 | 0 | 16 | 0.240->0.325 | 0.085 | 0.213 | - | - | - | - | 0.394 | 0.014->0.000 | - | - |
| bank0 | 1 | 16 | 0.259->0.779 | 0.519 | 4.852 | 1.694 | 3.158 [1.669, 4.789] | 0.276 | 0.529 | 0.394 | 0.013->0.000 | 0.000 | 0.000 |
| bank0 | 4 | 16 | 0.252->0.911 | 0.658 | 5.831 | 2.715 | 3.117 [2.245, 4.089] | 0.273 | 0.642 | 0.394 | 0.012->0.000 | 0.000 | 0.000 |
| bank0 | 16 | 16 | 0.260->0.920 | 0.660 | 6.611 | 3.533 | 3.078 [1.991, 4.163] | 0.402 | 0.658 | 0.394 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 0 | 16 | 0.240->0.325 | 0.085 | 0.213 | - | - | - | - | 0.394 | 0.014->0.000 | - | - |
| pooled | 1 | 16 | 0.259->0.779 | 0.519 | 4.852 | 1.694 | 3.158 [1.669, 4.789] | 0.276 | 0.529 | 0.394 | 0.013->0.000 | 0.000 | 0.000 |
| pooled | 4 | 16 | 0.252->0.911 | 0.658 | 5.831 | 2.715 | 3.117 [2.245, 4.089] | 0.273 | 0.642 | 0.394 | 0.012->0.000 | 0.000 | 0.000 |
| pooled | 16 | 16 | 0.260->0.920 | 0.660 | 6.611 | 3.533 | 3.078 [1.991, 4.163] | 0.402 | 0.658 | 0.394 | 0.012->0.000 | 0.000 | 0.000 |
