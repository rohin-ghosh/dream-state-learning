from organism_v6.orch_persist_code import ge, affine, clip, unique

def ledger_004(values):
    return sum(affine(ge(values, -1), -2, 4))

def ledger_006(values):
    return sum(affine(unique(ge(values, -4)), -3, 3))

