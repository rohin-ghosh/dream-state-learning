# RICH-L2-PILOT — prospective bootstrap and task binding

Allocation: Main49afa9b5 / STATE→BOARD00:51, September15,2026. FULL/OFF
bootstrap only on A1003, then explicit release and transfer of saved children;
node2physical4–7 respectively guided+sleep, guidedFROZEN, unparented+sleep,
bootstrapOFF readouts. One four-hour clock from first pilot native start;
16aggregate assigned GPU-hours,1536 learner calls,192 actual parent-provider
calls including failures. No duplicate bootstrap, retries, timer reset, fit
threshold,1000-row gate or parent access to sealed readouts.

## Bootstrap

Freeze all16 rows in INTENSITY first-qualified ADMITTED.json, SHA
52197d8d0f73528af69b61e6f244e5b1570f2bcfafd5ebb79d4058c959946837.
This early percentages-only packet is not a selected winning generator.
Both fresh native processes load original37ec; unchanged rank8 FP32 LoRA,
frozen Qwen2.5-7B-Instruct base. Existing AdamW recipe, seed8203, learning
rate3e-5, fresh optimizer; no base training. Canonical222 legacy rows re-encode
exactly against OLD_MASKS. Sixteen presentations per new target and per each
of12 existing trajectories gives224 updates, four rows/update. Both arms have
the identical schedule, old-memory/behavior/trajectory labels and matched
full-reference loss denominator; OFF masks only the16 new target rows.
All neutral-prefix labels masked; supervise exact complete child target plus
native end-of-turn. No cropping, rephrasing, segmentation, padding or examples.
Actual output hashes, even equal hashes, are valid observations. Bootstrap
native work consumes wall/GPU budget but no learner generation calls.

## Small designated L2 environment

PM_CONGRUENCE_JOIN_V1 combines two given congruences with coprime moduli.
Child must return the least nonnegative simultaneous solution, explaining any
work/check in its own words, with exact FINAL numeric syntax. Four modulus
pairs:7/11,11/13,13/17,17/19. Deterministic task identities fix three8-task
experience cohorts and four8-task held cohorts before native work, with no
duplicate question/residue tuples. Exhaustive enumeration below the product
certifies one reference answer for every task; this is finite arithmetic, not
general proof verification. No L1 mined/held or reserved L3 task family used.
Reference answers never appear in child prompts or parent inputs.

Same-stage held tasks are common to all four arms and run in fresh processes
without parent, hints, sleep context or persistent in-context records. Every
readout also uses unchanged W0/W8 and audit retention material. Preserve failed
source/answers and all zero-update sleeps. A cross-cohort increase alone is not
learning. Guided+sleep versus guidedFROZEN isolates changed learner state only
to the extent experience/admission histories match; unparented+sleep controls
parent effects, and bootstrapOFF controls bootstrap labels plus common legacy.
BOOTSTRAP_OFF is a readout control, not an extra experience/training lane.

Experience design cap: up to three child solution attempts and one own record
per task. Parent sees only current nonsealed question/actual learner history
and truthful success/failure, offers at most two short coaching responses and
one full-text admission review. No gold, sealed scores or other child's text.
No new semantic acceptance rule: outcome plus actual-token150–400 and the
existing substantive/gold/neutral-support gate. Only whole child-native targets
pass; private parent text and generation instructions removed/masked. Each
guided lane24tasks×3provider calls≤72, both≤144 (global192 cap remains).
At most288 experience learner calls plus896 held/retention calls=1184≤1536.
Exact parent service and experience/sleep implementation still require their
own CPU/provenance publication before these stages; bootstrap does not depend
on, launch or claim them complete.

Adversarial prediction: extra in-context coaching or task ease may explain
success without retained state change. Stronger evidence requires actual
nonzero updates, same-stage frozen comparisons and preserved retention;
unsupported autobiographical narration and unchanged/null weights falsify
the realized treatment, not the developmental thesis. No superiority claim
from this packet, no fit/scale beyond these exact bootstrap and pilot cycles.

## Lane realization before any held/experience calls — September15

Oracle clarification: enumeration is the exact8/8 reference ceiling, not a
beatable heuristic competitor. COHORT20ec0c83 and its oracle bytes remain
unchanged. No new heuristic baseline or campaign acceptance rule is added.

The existing Claude CLI parent transport can report a utility and evaluation
provider component per invocation. Reserve TWO provider calls before every
dispatch, count observed model usage separately and retain unknown/error usage;
no retries or unseen fallback. Actual lane policy uses ONE brief coaching
opportunity after the first real attempt on each guided episode (48invocations),
and one batched full-text review for each pair of episodes on all three learning
lanes (up to36invocations, at most8whole candidate targets/batch). Thus at most
84invocations/168reserved provider calls≤192, rather than miscounting requests
as provider calls. No separate distillation/reviewer calls. This tightens the
earlier opportunity upper bound prospectively; no L2 generation occurred first.

Parent sees current first attempt, truthful outcome and actual own records
from recent episodes/previous cycle, including prior admission count. It
focuses on learning from feedback, consequential checks, revisions and later
record use. It cannot see reference answers, held tasks/results or other
learners. All full-text admission reviews, including unparented material, see
only the candidate and neutral prefix; they do not provide learner coaching.
The unchanged math substantive/outcome/gold/neutral-support gate is invoked
directly. Exact enumerated question gold, not provider opinion, validates gold.

Neutral readouts are one512-token-capped attempt on each common8-task held
cohort plus unchanged48 W0/W8/audit calls. Parents, caches of experience text,
guidance and sleep prompts are absent; fresh native process every stage.
Up to three solution calls and a conditional own-record call per experience;
zero-yield or frozen sleep preserves input identity without a native fit.
Other sleeps use the existing four-presentation mixed legacy replay recipe,
reset optimizer and record actual saved output identities. Each learning lane
starts from the exact same FULL bootstrap; OFF is readout-only from its saved
masked bootstrap. No duplicate training on node2.
